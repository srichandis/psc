<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="scroll-smooth">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Premier Specialist Clinic | Specialist Care with a Personal Approach')</title>
    <meta name="description" content="@yield('meta_description', 'Expert medical care across neurology, psychiatry, psychology, endocrinology and nephrology in Coomera QLD.')">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&family=Newsreader:ital,opsz,wght@0,6..72,400..700;1,6..72,400..700&family=Plus+Jakarta+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">

    <!-- Tailwind CSS & Alpine.js via Vite -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    
    <!-- Alpine.js CDN fallback for instant prototyping -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <style>
        .font-editorial { font-family: 'Newsreader', Georgia, serif; }
        .font-script { font-family: 'Caveat', cursive; }
        [x-cloak] { display: none !important; }
    </style>

    @stack('styles')
</head>
<body class="bg-[#f4f8fa] text-slate-800 antialiased font-sans flex flex-col min-h-screen">
    <!-- Dynamic Navigation Bar Component -->
    <x-navbar />

    <!-- Main Content -->
    <main class="flex-grow">
        @yield('content')
    </main>

    <!-- Global Appointment Modal Component -->
    @include('components.appointment-modal')

    <!-- Footer Component -->
    <x-footer />

    @stack('scripts')
</body>
</html>
