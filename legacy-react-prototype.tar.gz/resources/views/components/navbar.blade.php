@props([
    'active' => 'home'
])

<nav 
    x-data="{ 
        scrolled: false, 
        mobileOpen: false,
        specialtiesDropdown: false 
    }"
    x-init="window.addEventListener('scroll', () => { scrolled = window.scrollY > 20 })"
    :class="scrolled ? 'bg-white/95 backdrop-blur-md shadow-sm border-b border-slate-100 py-3' : 'bg-transparent py-4 sm:py-5 border-b border-slate-200/60'"
    class="sticky top-0 z-50 transition-all duration-300 w-full"
    id="main-nav"
>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between">
            <!-- Brand Logo -->
            <a href="{{ route('home') ?? '#' }}" class="flex items-center gap-3.5 group" id="brand-logo-link">
                <!-- Dual Eucalyptus Leaves Logo Emblem -->
                <div class="w-10 h-10 sm:w-11 sm:h-11 relative flex-shrink-0 text-[#103d52] group-hover:scale-105 transition-transform">
                    <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                        <!-- Primary leaf (navy/teal) -->
                        <path d="M72 18C72 18 42 22 28 50C16 74 32 88 44 86C60 84 76 66 82 42C86 26 72 18 72 18Z" fill="#103D52" opacity="0.95"/>
                        <path d="M30 68C42 54 58 40 76 28" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round" opacity="0.6"/>
                        <!-- Secondary accent leaf (sage/forest) -->
                        <path d="M48 30C48 30 24 38 18 60C14 74 24 82 34 80C46 76 56 62 60 48C62 38 48 30 48 30Z" fill="#247871" opacity="0.9"/>
                        <path d="M22 68C32 58 42 48 54 40" stroke="#ffffff" stroke-width="2" stroke-linecap="round" opacity="0.5"/>
                    </svg>
                </div>
                
                <div class="flex flex-col">
                    <div class="flex items-baseline gap-1.5">
                        <span class="font-editorial text-2xl sm:text-3xl font-bold tracking-tight text-[#103d52] leading-none">PREMIER</span>
                    </div>
                    <span class="text-[10px] sm:text-[11px] font-semibold tracking-[0.24em] text-[#103d52] uppercase leading-tight mt-0.5">SPECIALIST CLINIC</span>
                    <span class="text-[11px] sm:text-xs italic text-[#227066] font-editorial leading-none mt-0.5 font-normal">Expert care for a healthier tomorrow</span>
                </div>
            </a>

            <!-- Desktop Navigation Links -->
            <div class="hidden lg:flex items-center space-x-7">
                <a 
                    href="#home" 
                    class="relative py-2 text-sm font-semibold tracking-wide transition-colors text-[#103d52] border-b-2 border-[#247871]"
                    id="nav-link-home"
                >
                    Home
                </a>

                <a 
                    href="#specialists" 
                    class="relative py-2 text-sm font-medium tracking-wide text-slate-700 hover:text-[#103d52] transition-colors"
                    id="nav-link-specialists"
                >
                    Our Specialists
                </a>

                <!-- Specialties Dropdown -->
                <div 
                    class="relative" 
                    @mouseenter="specialtiesDropdown = true" 
                    @mouseleave="specialtiesDropdown = false"
                >
                    <a 
                        href="#specialties" 
                        class="inline-flex items-center gap-1 py-2 text-sm font-medium tracking-wide text-slate-700 hover:text-[#103d52] transition-colors"
                        id="nav-link-specialties"
                    >
                        Specialties
                        <svg class="w-3.5 h-3.5 text-slate-500 transition-transform duration-200" :class="specialtiesDropdown ? 'rotate-180' : ''" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </a>

                    <!-- Dropdown Menu -->
                    <div 
                        x-show="specialtiesDropdown" 
                        x-cloak
                        x-transition:enter="transition ease-out duration-150"
                        x-transition:enter-start="opacity-0 translate-y-1"
                        x-transition:enter-end="opacity-100 translate-y-0"
                        x-transition:leave="transition ease-in duration-100"
                        x-transition:leave-start="opacity-100 translate-y-0"
                        x-transition:leave-end="opacity-0 translate-y-1"
                        class="absolute top-full left-0 w-64 mt-1 bg-white rounded-lg shadow-xl border border-slate-100 py-2 z-50"
                    >
                        <a href="#specialties" class="block px-4 py-2.5 text-xs font-semibold uppercase tracking-wider text-slate-400">Clinical Disciplines</a>
                        <a href="#specialties" class="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 hover:text-[#103d52] transition-colors">Neurology</a>
                        <a href="#specialties" class="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 hover:text-[#103d52] transition-colors">Psychology</a>
                        <a href="#specialties" class="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 hover:text-[#103d52] transition-colors">Psychiatry</a>
                        <a href="#specialties" class="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 hover:text-[#103d52] transition-colors">Endocrinology</a>
                        <a href="#specialties" class="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 hover:text-[#103d52] transition-colors">Nephrology</a>
                    </div>
                </div>

                <a 
                    href="#visit-process" 
                    class="py-2 text-sm font-medium tracking-wide text-slate-700 hover:text-[#103d52] transition-colors"
                    id="nav-link-patients"
                >
                    For Patients
                </a>

                <a 
                    href="#location" 
                    class="py-2 text-sm font-medium tracking-wide text-slate-700 hover:text-[#103d52] transition-colors"
                    id="nav-link-about"
                >
                    About Us
                </a>

                <a 
                    href="#location" 
                    class="py-2 text-sm font-medium tracking-wide text-slate-700 hover:text-[#103d52] transition-colors"
                    id="nav-link-contact"
                >
                    Contact
                </a>
            </div>

            <!-- Right Actions: Phone + Book CTA -->
            <div class="hidden sm:flex items-center space-x-5">
                <!-- Phone Direct Link -->
                <a 
                    href="tel:0755000536" 
                    class="inline-flex items-center gap-2 text-sm font-semibold text-[#103d52] hover:text-[#247871] transition-colors px-2 py-1.5"
                    title="Call reception"
                    id="nav-phone-cta"
                >
                    <div class="w-7 h-7 rounded-full bg-emerald-50 text-[#247871] flex items-center justify-center">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                        </svg>
                    </div>
                    <span>(07) 5500 0536</span>
                </a>

                <!-- Appointment Booking Button -->
                <button 
                    type="button"
                    @click="$dispatch('open-appointment-modal')" 
                    class="inline-flex items-center justify-center px-5 py-2.5 text-sm font-medium text-white bg-[#103d52] hover:bg-[#0c2b3a] rounded-md transition-all shadow-sm hover:shadow active:scale-[0.98]"
                    id="nav-book-button"
                >
                    Book an Appointment
                </button>
            </div>

            <!-- Mobile Hamburger Toggle -->
            <div class="flex items-center lg:hidden space-x-2">
                <a 
                    href="tel:0755000536" 
                    class="p-2 text-[#103d52] hover:bg-slate-100 rounded-md sm:hidden"
                    aria-label="Call clinic"
                >
                    <svg class="w-5 h-5 text-[#247871]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                </a>
                
                <button 
                    type="button" 
                    @click="mobileOpen = !mobileOpen"
                    class="p-2 text-slate-700 hover:text-[#103d52] hover:bg-slate-100 rounded-md focus:outline-none focus:ring-2 focus:ring-[#103d52]"
                    id="mobile-menu-toggle"
                    aria-label="Toggle mobile menu"
                >
                    <svg x-show="!mobileOpen" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                    <svg x-show="mobileOpen" x-cloak class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <!-- Mobile Drawer Menu -->
    <div 
        x-show="mobileOpen" 
        x-cloak
        x-transition:enter="transition ease-out duration-200"
        x-transition:enter-start="opacity-0 -translate-y-2"
        x-transition:enter-end="opacity-100 translate-y-0"
        x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100 translate-y-0"
        x-transition:leave-end="opacity-0 -translate-y-2"
        class="lg:hidden bg-white border-b border-slate-200 px-4 pt-3 pb-6 space-y-3 shadow-lg"
        id="mobile-nav-drawer"
    >
        <div class="space-y-1">
            <a href="#home" @click="mobileOpen = false" class="block px-3 py-2 text-base font-semibold text-[#103d52] bg-slate-50 rounded-md">Home</a>
            <a href="#specialists" @click="mobileOpen = false" class="block px-3 py-2 text-base font-medium text-slate-700 hover:bg-slate-50 hover:text-[#103d52] rounded-md">Our Specialists</a>
            <a href="#specialties" @click="mobileOpen = false" class="block px-3 py-2 text-base font-medium text-slate-700 hover:bg-slate-50 hover:text-[#103d52] rounded-md">Specialties</a>
            <a href="#visit-process" @click="mobileOpen = false" class="block px-3 py-2 text-base font-medium text-slate-700 hover:bg-slate-50 hover:text-[#103d52] rounded-md">For Patients</a>
            <a href="#location" @click="mobileOpen = false" class="block px-3 py-2 text-base font-medium text-slate-700 hover:bg-slate-50 hover:text-[#103d52] rounded-md">About Us</a>
            <a href="#location" @click="mobileOpen = false" class="block px-3 py-2 text-base font-medium text-slate-700 hover:bg-slate-50 hover:text-[#103d52] rounded-md">Contact</a>
        </div>

        <div class="pt-4 border-t border-slate-100 flex flex-col gap-3">
            <a 
                href="tel:0755000536" 
                class="flex items-center justify-center gap-2 w-full py-2.5 text-sm font-semibold text-[#103d52] bg-slate-100 hover:bg-slate-200 rounded-md"
            >
                <svg class="w-4 h-4 text-[#247871]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
                <span>Call (07) 5500 0536</span>
            </a>

            <button 
                type="button" 
                @click="mobileOpen = false; $dispatch('open-appointment-modal')" 
                class="w-full py-2.5 text-sm font-medium text-center text-white bg-[#103d52] hover:bg-[#0c2b3a] rounded-md shadow"
            >
                Book an Appointment
            </button>
        </div>
    </div>
</nav>
