@props([
    'number',
    'title',
    'description',
    'icon' => 'file',
    'isLast' => false
])

<div class="relative flex flex-col items-center text-center group">
    <!-- Icon and Number Badges -->
    <div class="flex items-center gap-3 mb-5">
        <!-- Number Circle (Dark Teal) -->
        <div class="w-12 h-12 rounded-full bg-[#103d52] text-white flex items-center justify-center font-editorial font-bold text-lg shadow-sm">
            {{ $number }}
        </div>

        <!-- Medical Icon Badge (Soft Mint/Teal Tint) -->
        <div class="w-12 h-12 rounded-full bg-[#e8f3f2] text-[#247871] flex items-center justify-center border border-[#c4e2de]">
            @if($icon === 'file')
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
            @elseif($icon === 'phone')
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
            @elseif($icon === 'calendar')
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
            @elseif($icon === 'users')
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
            @endif
        </div>
    </div>

    <!-- Title -->
    <h3 class="font-editorial text-lg font-bold text-[#103d52] mb-2">
        {{ $title }}
    </h3>

    <!-- Description -->
    <p class="text-xs text-slate-600 leading-relaxed max-w-[220px]">
        {!! $description !!}
    </p>

    <!-- Connector Arrow (Desktop only) -->
    @if(!$isLast)
        <div class="hidden lg:block absolute top-6 -right-6 text-slate-300">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
            </svg>
        </div>
    @endif
</div>
