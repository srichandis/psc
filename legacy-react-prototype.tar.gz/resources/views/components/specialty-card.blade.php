@props([
    'title',
    'description',
    'icon' => 'brain',
    'url' => '#'
])

<div class="bg-white rounded-xl p-6 border border-slate-200/90 shadow-sm hover:shadow-md hover:-translate-y-1 transition-all duration-200 flex flex-col justify-between text-center group">
    <div>
        <!-- Icon Container -->
        <div class="w-16 h-16 mx-auto mb-4 text-[#247871] group-hover:text-[#103d52] transition-colors flex items-center justify-center">
            @if($icon === 'brain')
                <!-- Brain / Neurology SVG -->
                <svg class="w-12 h-12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"/>
                    <path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"/>
                    <path d="M12 5v13"/>
                    <path d="M7 11h2"/>
                    <path d="M15 11h2"/>
                </svg>
            @elseif($icon === 'psychology')
                <!-- Head / Profile with thought / cognition -->
                <svg class="w-12 h-12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M15 2a4 4 0 0 0-4 4v1H8a3 3 0 0 0-3 3v2a3 3 0 0 0 2 2.82V16a4 4 0 0 0 4 4h1v2"/>
                    <circle cx="16" cy="9" r="2.5"/>
                    <path d="M18 14c1.5 0 3 .8 3 2.5V19"/>
                </svg>
            @elseif($icon === 'psychiatry')
                <!-- Brain with hands / care emblem -->
                <svg class="w-12 h-12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 21a9 9 0 0 0 9-9c0-4.97-4.03-9-9-9s-9 4.03-9 9a9 9 0 0 0 9 9z"/>
                    <path d="M8 12c0-2.2 1.8-4 4-4s4 1.8 4 4"/>
                    <path d="M12 12v4"/>
                    <circle cx="12" cy="12" r="1"/>
                </svg>
            @elseif($icon === 'endocrinology')
                <!-- Butterfly / Thyroid gland outline -->
                <svg class="w-12 h-12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 15V9"/>
                    <path d="M8 8c-3-2-6 0-6 4s3 6 6 4c1.5-.7 3-3 4-7"/>
                    <path d="M16 8c3-2 6 0 6 4s-3 6-6 4c-1.5-.7-3-3-4-7"/>
                </svg>
            @elseif($icon === 'nephrology')
                <!-- Kidney dual lobes outline -->
                <svg class="w-12 h-12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M7 6c-2.5 0-4.5 2.5-4.5 6s2 6.5 4.5 6.5c3 0 4-3 4-6.5S9.5 6 7 6Z"/>
                    <path d="M17 6c2.5 0 4.5 2.5 4.5 6s-2 6.5-4.5 6.5c-3 0-4-3-4-6.5S14.5 6 17 6Z"/>
                    <path d="M11 12h2"/>
                </svg>
            @endif
        </div>

        <h3 class="font-editorial text-lg font-bold text-[#103d52] mb-2.5">
            {{ $title }}
        </h3>

        <p class="text-xs text-slate-600 leading-relaxed line-clamp-3">
            {{ $description }}
        </p>
    </div>

    <div class="pt-5 mt-4 border-t border-slate-100">
        <a 
            href="{{ $url }}" 
            class="inline-flex items-center gap-1 text-xs font-bold text-[#103d52] group-hover:text-[#247871] transition-colors"
        >
            <span>Learn More</span>
            <svg class="w-3.5 h-3.5 transform group-hover:translate-x-0.5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
        </a>
    </div>
</div>
