<div 
    x-data="{ 
        open: false,
        submitted: false,
        form: {
            name: '',
            phone: '',
            email: '',
            specialty: 'Neurology',
            referralReady: 'yes',
            notes: ''
        }
    }"
    @open-appointment-modal.window="open = true; submitted = false"
    @keydown.escape.window="open = false"
    x-show="open" 
    x-cloak
    class="relative z-50"
    aria-labelledby="modal-title" 
    role="dialog" 
    aria-modal="true"
>
    <!-- Backdrop -->
    <div 
        x-show="open"
        x-transition:enter="ease-out duration-300"
        x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100"
        x-transition:leave="ease-in duration-200"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0"
        class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"
        @click="open = false"
    ></div>

    <div class="fixed inset-0 z-10 w-screen overflow-y-auto p-4 sm:p-6 lg:p-8 flex items-center justify-center">
        <div 
            x-show="open"
            x-transition:enter="ease-out duration-300"
            x-transition:enter-start="opacity-0 scale-95"
            x-transition:enter-end="opacity-100 scale-100"
            x-transition:leave="ease-in duration-200"
            x-transition:leave-start="opacity-100 scale-100"
            x-transition:leave-end="opacity-0 scale-95"
            class="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all w-full max-w-lg border border-slate-100"
            @click.stop
        >
            <!-- Modal Header -->
            <div class="bg-[#103d52] px-6 py-5 text-white flex items-center justify-between">
                <div>
                    <h3 class="font-editorial text-xl font-bold" id="modal-title">Request an Appointment</h3>
                    <p class="text-xs text-teal-100 mt-0.5">Premier Specialist Clinic &bull; Coomera QLD</p>
                </div>
                <button 
                    type="button" 
                    @click="open = false" 
                    class="rounded-lg p-1 text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
                >
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>

            <!-- Modal Body -->
            <div class="p-6">
                <!-- Referral Notice Banner -->
                <div class="bg-amber-50/80 border border-amber-200 rounded-lg p-3.5 mb-5 flex items-start gap-3 text-xs text-amber-900">
                    <svg class="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span><strong>Please Note:</strong> A valid GP or specialist referral is required prior to your consultation to be eligible for Medicare rebates.</span>
                </div>

                <template x-if="!submitted">
                    <form @submit.prevent="submitted = true" class="space-y-4 text-xs">
                        <div>
                            <label class="block font-semibold text-slate-700 mb-1">Full Patient Name *</label>
                            <input 
                                type="text" 
                                required
                                x-model="form.name"
                                placeholder="e.g. John Smith"
                                class="w-full px-3.5 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#103d52] focus:border-transparent"
                            >
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                                <label class="block font-semibold text-slate-700 mb-1">Contact Phone *</label>
                                <input 
                                    type="tel" 
                                    required
                                    x-model="form.phone"
                                    placeholder="e.g. 0412 345 678"
                                    class="w-full px-3.5 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#103d52] focus:border-transparent"
                                >
                            </div>
                            <div>
                                <label class="block font-semibold text-slate-700 mb-1">Email Address</label>
                                <input 
                                    type="email" 
                                    x-model="form.email"
                                    placeholder="john@example.com"
                                    class="w-full px-3.5 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#103d52] focus:border-transparent"
                                >
                            </div>
                        </div>

                        <div>
                            <label class="block font-semibold text-slate-700 mb-1">Select Specialty</label>
                            <select 
                                x-model="form.specialty"
                                class="w-full px-3.5 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#103d52] focus:border-transparent bg-white"
                            >
                                <option value="Neurology">Neurology (Dr Sarah Tanusha Thomas)</option>
                                <option value="Psychiatry">Psychiatry (Dr Sadasivan)</option>
                                <option value="Endocrinology">Endocrinology (Dr Subakumar / Dr Harish Venugopal)</option>
                                <option value="Nephrology">Nephrology (Dr Thomas Titus)</option>
                                <option value="Psychology">Psychology (Gagandeep Singh)</option>
                            </select>
                        </div>

                        <div>
                            <label class="block font-semibold text-slate-700 mb-1">Do you currently have a referral?</label>
                            <div class="grid grid-cols-3 gap-2 mt-1">
                                <label class="flex items-center gap-2 p-2 border rounded-lg cursor-pointer hover:bg-slate-50 text-slate-700">
                                    <input type="radio" value="yes" x-model="form.referralReady" name="referral" class="text-[#103d52]">
                                    <span>Yes, ready</span>
                                </label>
                                <label class="flex items-center gap-2 p-2 border rounded-lg cursor-pointer hover:bg-slate-50 text-slate-700">
                                    <input type="radio" value="pending" x-model="form.referralReady" name="referral" class="text-[#103d52]">
                                    <span>In progress</span>
                                </label>
                                <label class="flex items-center gap-2 p-2 border rounded-lg cursor-pointer hover:bg-slate-50 text-slate-700">
                                    <input type="radio" value="no" x-model="form.referralReady" name="referral" class="text-[#103d52]">
                                    <span>Need help</span>
                                </label>
                            </div>
                        </div>

                        <div>
                            <label class="block font-semibold text-slate-700 mb-1">Additional Information (Optional)</label>
                            <textarea 
                                rows="2"
                                x-model="form.notes"
                                placeholder="Any preferred days, specific symptoms or refering GP..."
                                class="w-full px-3.5 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#103d52] focus:border-transparent"
                            ></textarea>
                        </div>

                        <div class="pt-2 flex items-center justify-end gap-3">
                            <button 
                                type="button" 
                                @click="open = false" 
                                class="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-medium"
                            >
                                Cancel
                            </button>
                            <button 
                                type="submit" 
                                class="px-5 py-2 rounded-lg bg-[#103d52] hover:bg-[#0c2b3a] text-white font-semibold transition-all shadow"
                            >
                                Submit Request
                            </button>
                        </div>
                    </form>
                </template>

                <template x-if="submitted">
                    <div class="py-8 text-center space-y-3">
                        <div class="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                            </svg>
                        </div>
                        <h4 class="font-editorial text-xl font-bold text-[#103d52]">Thank You, <span x-text="form.name"></span></h4>
                        <p class="text-xs text-slate-600 max-w-sm mx-auto">
                            Our reception staff will review your request and call you shortly on <span class="font-semibold text-slate-800" x-text="form.phone"></span> to confirm your appointment time and referral details.
                        </p>
                        <div class="pt-4">
                            <button 
                                type="button" 
                                @click="open = false" 
                                class="px-5 py-2 bg-[#103d52] text-white rounded-lg text-xs font-semibold"
                            >
                                Close
                            </button>
                        </div>
                    </div>
                </template>
            </div>
        </div>
    </div>
</div>
