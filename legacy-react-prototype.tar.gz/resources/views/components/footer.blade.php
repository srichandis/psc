<footer class="bg-[#103d52] text-slate-200 mt-20 pt-16 pb-12" id="site-footer">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-12 pb-14 border-b border-slate-700/60">
            <!-- Brand Column -->
            <div class="space-y-4">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 relative flex-shrink-0 text-white">
                        <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                            <path d="M72 18C72 18 42 22 28 50C16 74 32 88 44 86C60 84 76 66 82 42C86 26 72 18 72 18Z" fill="#ffffff" opacity="0.95"/>
                            <path d="M48 30C48 30 24 38 18 60C14 74 24 82 34 80C46 76 56 62 60 48C62 38 48 30 48 30Z" fill="#38b2ac" opacity="0.9"/>
                        </svg>
                    </div>
                    <div>
                        <span class="font-editorial text-2xl font-bold tracking-tight text-white block leading-none">PREMIER</span>
                        <span class="text-[10px] font-semibold tracking-[0.22em] text-teal-200 uppercase block mt-0.5">SPECIALIST CLINIC</span>
                        <span class="text-xs italic text-teal-100 font-editorial block mt-0.5">Expert care for a healthier tomorrow</span>
                    </div>
                </div>

                <p class="text-xs text-slate-300 leading-relaxed pt-2 pr-4">
                    Specialist care across neurology, psychiatry, psychology, endocrinology and nephrology.
                </p>
            </div>

            <!-- Quick Links -->
            <div>
                <h4 class="text-sm font-semibold tracking-wider text-white uppercase mb-4">Quick Links</h4>
                <ul class="space-y-2.5 text-xs text-slate-300">
                    <li><a href="#home" class="hover:text-teal-200 transition-colors">Home</a></li>
                    <li><a href="#specialists" class="hover:text-teal-200 transition-colors">Our Specialists</a></li>
                    <li><a href="#specialties" class="hover:text-teal-200 transition-colors">Specialties</a></li>
                    <li><a href="#visit-process" class="hover:text-teal-200 transition-colors">For Patients</a></li>
                    <li><a href="#location" class="hover:text-teal-200 transition-colors">About Us</a></li>
                    <li><a href="#location" class="hover:text-teal-200 transition-colors">Contact</a></li>
                </ul>
            </div>

            <!-- Patient Information -->
            <div>
                <h4 class="text-sm font-semibold tracking-wider text-white uppercase mb-4">Patient Information</h4>
                <ul class="space-y-2.5 text-xs text-slate-300">
                    <li><a href="#visit-process" class="hover:text-teal-200 transition-colors">Appointments</a></li>
                    <li><a href="#visit-process" class="hover:text-teal-200 transition-colors">Referral Information</a></li>
                    <li><a href="#location" class="hover:text-teal-200 transition-colors">Parking</a></li>
                    <li><a href="#visit-process" class="hover:text-teal-200 transition-colors">FAQs</a></li>
                    <li><a href="#home" class="hover:text-teal-200 transition-colors">Privacy Policy</a></li>
                </ul>
            </div>

            <!-- Get In Touch -->
            <div>
                <h4 class="text-sm font-semibold tracking-wider text-white uppercase mb-4">Get In Touch</h4>
                <ul class="space-y-3.5 text-xs text-slate-300">
                    <li class="flex items-start gap-3">
                        <svg class="w-4 h-4 text-teal-300 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                        <span>4 Jowett Street,<br>Coomera QLD 4209</span>
                    </li>
                    <li class="flex items-center gap-3">
                        <svg class="w-4 h-4 text-teal-300 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                        </svg>
                        <a href="tel:0755000536" class="hover:text-white transition-colors">(07) 5500 0536</a>
                    </li>
                    <li class="flex items-center gap-3">
                        <svg class="w-4 h-4 text-teal-300 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                        <button type="button" @click="$dispatch('open-appointment-modal')" class="hover:text-white transition-colors text-left">Send us a message</button>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Copyright Bottom Row -->
        <div class="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
            <p>© {{ date('Y') }} Premier Specialist Clinic. All rights reserved.</p>
            <p class="font-script text-lg sm:text-xl text-teal-100 tracking-wide">
                People. Specialist care. Brighter tomorrows.
            </p>
        </div>
    </div>
</footer>
