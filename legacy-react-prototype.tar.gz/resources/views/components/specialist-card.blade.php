@props([
    'name',
    'qualifications',
    'role',
    'image',
    'profileUrl' => '#'
])

<div class="bg-white rounded-xl border border-slate-200/90 shadow-sm hover:shadow-md transition-all duration-200 flex flex-col overflow-hidden group">
    <!-- Image with aspect ratio and subtle hover zoom -->
    <div class="aspect-[4/3] w-full overflow-hidden bg-slate-100 relative">
        <img 
            src="{{ $image }}" 
            alt="{{ $name }}" 
            class="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
        />
        <div class="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
    </div>

    <!-- Content Box -->
    <div class="p-5 flex flex-col flex-grow justify-between">
        <div class="space-y-1.5">
            <h3 class="font-editorial text-xl font-bold text-[#103d52] leading-snug">
                {{ $name }}
            </h3>
            <p class="text-[11px] font-medium text-slate-500 tracking-tight leading-normal">
                {{ $qualifications }}
            </p>
            <p class="text-xs font-semibold text-[#247871] pt-1 leading-snug">
                {{ $role }}
            </p>
        </div>

        <div class="pt-4 mt-auto">
            <a 
                href="{{ $profileUrl }}" 
                class="inline-flex items-center gap-1 text-xs font-bold text-[#103d52] group-hover:text-[#247871] transition-colors"
            >
                <span>View Profile</span>
                <svg class="w-3.5 h-3.5 transform group-hover:translate-x-0.5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
            </a>
        </div>
    </div>
</div>
