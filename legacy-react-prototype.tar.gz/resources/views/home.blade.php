@extends('layouts.app')

@section('title', 'Premier Specialist Clinic | Specialist Care with a Personal Approach')
@section('meta_description', 'Expert medical care across neurology, psychiatry, psychology, endocrinology and nephrology at 4 Jowett Street, Coomera QLD.')

@section('content')
<div id="home" class="space-y-16 sm:space-y-24">

    <!-- ==========================================
         HERO SECTION
         ========================================== -->
    <section class="relative overflow-hidden pt-6 sm:pt-10 lg:pt-14">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
                
                <!-- Left Hero Content (Col 1-7) -->
                <div class="lg:col-span-7 space-y-6 sm:space-y-8 z-10">
                    <div class="space-y-4 max-w-2xl">
                        <h1 class="font-editorial text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#103d52] leading-[1.12]">
                            Specialist care<br>
                            with a personal approach
                        </h1>
                        <p class="text-base sm:text-lg text-slate-600 font-normal leading-relaxed max-w-xl">
                            Expert medical care across neurology, psychiatry, psychology, endocrinology and nephrology.
                        </p>
                    </div>

                    <!-- Call To Action Buttons -->
                    <div class="flex flex-wrap items-center gap-3.5 pt-1">
                        <button 
                            type="button"
                            @click="$dispatch('open-appointment-modal')"
                            class="inline-flex items-center gap-2 px-6 py-3.5 rounded-md text-sm font-semibold text-white bg-[#103d52] hover:bg-[#0c2b3a] transition-all shadow-sm hover:shadow active:scale-[0.98]"
                            id="hero-book-btn"
                        >
                            <span>Book an Appointment</span>
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                            </svg>
                        </button>

                        <a 
                            href="tel:0755000536"
                            class="inline-flex items-center gap-2 px-5 py-3.5 rounded-md text-sm font-semibold text-[#103d52] bg-white border border-[#103d52]/40 hover:bg-slate-50 transition-all active:scale-[0.98]"
                            id="hero-call-btn"
                        >
                            <svg class="w-4 h-4 text-[#247871]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                            </svg>
                            <span>Call (07) 5500 0536</span>
                        </a>
                    </div>

                    <!-- Address & Parking Callout Banner -->
                    <div class="flex items-start gap-3.5 pt-4 max-w-xl text-xs sm:text-sm text-slate-600">
                        <div class="w-8 h-8 rounded-full bg-[#103d52]/10 text-[#103d52] flex items-center justify-center flex-shrink-0 mt-0.5">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                            </svg>
                        </div>
                        <div>
                            <p class="font-bold text-[#103d52]">4 Jowett Street, Coomera QLD 4209</p>
                            <p class="text-xs text-slate-500 mt-0.5">Free on-site parking for patients, including accessible spaces.</p>
                        </div>
                    </div>
                </div>

                <!-- Right Hero Image with Script Overlay (Col 8-12) -->
                <div class="lg:col-span-5 relative mt-4 lg:mt-0">
                    <div class="relative rounded-2xl overflow-hidden shadow-lg border border-white/80 aspect-[5/4] sm:aspect-[4/3] lg:aspect-[5/4]">
                        <img 
                            src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1200&q=80" 
                            alt="Specialist care consultation at Premier Specialist Clinic" 
                            class="w-full h-full object-cover object-center"
                        />
                        <!-- Soft Gradient Veil -->
                        <div class="absolute inset-0 bg-gradient-to-t from-[#103d52]/50 via-transparent to-transparent"></div>

                        <!-- Handwritten Script Slogan Overlay (Bottom Right) -->
                        <div class="absolute bottom-4 right-5 text-right">
                            <p class="font-script text-2xl sm:text-3xl text-white font-normal drop-shadow-md leading-tight">
                                People.<br>
                                Specialist care.<br>
                                Brighter tomorrows.
                            </p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>


    <!-- ==========================================
         SECTION: OUR SPECIALISTS
         ========================================== -->
    <section id="specialists" class="scroll-mt-24">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- Section Header -->
            <div class="flex flex-col md:flex-row md:items-end justify-between mb-8 sm:mb-10 gap-4">
                <div class="space-y-2 max-w-2xl">
                    <span class="text-xs font-bold uppercase tracking-[0.2em] text-[#247871]">OUR SPECIALISTS</span>
                    <h2 class="font-editorial text-3xl sm:text-4xl font-bold text-[#103d52]">Meet Our Specialists</h2>
                    <p class="text-sm text-slate-600 leading-relaxed pt-1">
                        Our multidisciplinary team provides specialist assessment and care across a range of neurological, psychological, psychiatric, endocrine and kidney conditions.
                    </p>
                </div>
                <div>
                    <a 
                        href="#specialists" 
                        class="inline-flex items-center gap-1.5 text-xs font-bold text-[#103d52] hover:text-[#247871] transition-colors whitespace-nowrap"
                    >
                        <span>View All Specialists</span>
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                        </svg>
                    </a>
                </div>
            </div>

            <!-- Specialist Cards Grid (6 Doctors) -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-5 sm:gap-6">
                @foreach($specialists as $specialist)
                    <x-specialist-card 
                        :name="$specialist['name']"
                        :qualifications="$specialist['qualifications']"
                        :role="$specialist['role']"
                        :image="$specialist['image']"
                        :profileUrl="'#specialist-' . $specialist['id']"
                    />
                @endforeach
            </div>
        </div>
    </section>


    <!-- ==========================================
         SECTION: OUR SPECIALTIES
         ========================================== -->
    <section id="specialties" class="scroll-mt-24">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- Section Header -->
            <div class="flex flex-col md:flex-row md:items-end justify-between mb-8 sm:mb-10 gap-4">
                <div class="space-y-2">
                    <span class="text-xs font-bold uppercase tracking-[0.2em] text-[#247871]">OUR SPECIALTIES</span>
                    <h2 class="font-editorial text-3xl sm:text-4xl font-bold text-[#103d52]">Comprehensive Specialist Care</h2>
                </div>
                <div>
                    <a 
                        href="#specialties" 
                        class="inline-flex items-center gap-1.5 text-xs font-bold text-[#103d52] hover:text-[#247871] transition-colors whitespace-nowrap"
                    >
                        <span>Explore All Specialties</span>
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                        </svg>
                    </a>
                </div>
            </div>

            <!-- 5 Specialty Cards Grid -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5 sm:gap-6">
                <x-specialty-card 
                    title="Neurology"
                    description="Stroke, cognitive neurology, memory disorders, dementia and brain health."
                    icon="brain"
                    url="#neurology"
                />

                <x-specialty-card 
                    title="Psychology"
                    description="Assessment, therapy and mental health support for all ages."
                    icon="psychology"
                    url="#psychology"
                />

                <x-specialty-card 
                    title="Psychiatry"
                    description="Comprehensive assessment and treatment for adult mental health conditions."
                    icon="psychiatry"
                    url="#psychiatry"
                />

                <x-specialty-card 
                    title="Endocrinology"
                    description="Diabetes, thyroid disorders, osteoporosis, adrenal and pituitary disorders."
                    icon="endocrinology"
                    url="#endocrinology"
                />

                <x-specialty-card 
                    title="Nephrology"
                    description="Chronic kidney disease, dialysis, hypertension and transplantation."
                    icon="nephrology"
                    url="#nephrology"
                />
            </div>
        </div>
    </section>


    <!-- ==========================================
         SECTION: YOUR VISIT / PROCESS
         ========================================== -->
    <section id="visit-process" class="scroll-mt-24">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- Section Header -->
            <div class="flex flex-col md:flex-row md:items-end justify-between mb-10 sm:mb-12 gap-4">
                <div class="space-y-2">
                    <span class="text-xs font-bold uppercase tracking-[0.2em] text-[#247871]">YOUR VISIT</span>
                    <h2 class="font-editorial text-3xl sm:text-4xl font-bold text-[#103d52]">A Simple Appointment Process</h2>
                </div>
                <div>
                    <a 
                        href="#visit-process" 
                        class="inline-flex items-center gap-1.5 text-xs font-bold text-[#103d52] hover:text-[#247871] transition-colors whitespace-nowrap"
                    >
                        <span>More Information for Patients</span>
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                        </svg>
                    </a>
                </div>
            </div>

            <!-- 4 Connected Process Steps Grid -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-4 relative bg-white/70 p-8 rounded-2xl border border-slate-200/80 shadow-sm">
                <x-process-step 
                    number="01"
                    title="Get a Referral"
                    description="A referral from your GP or another specialist is required."
                    icon="file"
                    :isLast="false"
                />

                <x-process-step 
                    number="02"
                    title="Book Your Appointment"
                    description="Call our friendly reception team on <strong>(07) 5500 0536</strong>."
                    icon="phone"
                    :isLast="false"
                />

                <x-process-step 
                    number="03"
                    title="Prepare for Your Visit"
                    description="Bring your Medicare card and referral if not already provided."
                    icon="calendar"
                    :isLast="false"
                />

                <x-process-step 
                    number="04"
                    title="Meet Your Specialist"
                    description="Your specialist will assess your concerns and discuss next steps."
                    icon="users"
                    :isLast="true"
                />
            </div>
        </div>
    </section>


    <!-- ==========================================
         SECTION: OUR LOCATION & MAP
         ========================================== -->
    <section id="location" class="scroll-mt-24">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
                
                <!-- Left: Location Info Card (Col 1-4) -->
                <div class="lg:col-span-4 bg-white rounded-2xl p-7 border border-slate-200/90 shadow-sm flex flex-col justify-between">
                    <div class="space-y-4">
                        <h3 class="font-editorial text-2xl sm:text-3xl font-bold text-[#103d52]">
                            Our Location
                        </h3>

                        <div class="flex items-start gap-3 text-sm text-[#103d52] font-semibold">
                            <svg class="w-5 h-5 text-[#247871] flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                            </svg>
                            <span>4 Jowett Street,<br>Coomera QLD 4209</span>
                        </div>

                        <p class="text-xs text-slate-600 leading-relaxed pt-1">
                            We offer free but limited parking for patients in our on-site carpark, including designated spaces for patients with disabilities. Additional street parking is also available along Jowett Street.
                        </p>
                    </div>

                    <div class="pt-6">
                        <a 
                            href="https://maps.google.com/?q=4+Jowett+Street+Coomera+QLD+4209" 
                            target="_blank"
                            rel="noopener noreferrer"
                            class="inline-flex items-center justify-center gap-2 w-full sm:w-auto px-6 py-3 rounded-md text-xs font-bold text-white bg-[#103d52] hover:bg-[#0c2b3a] transition-all shadow-sm active:scale-[0.98]"
                        >
                            <span>Get Directions</span>
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                            </svg>
                        </a>
                    </div>
                </div>

                <!-- Middle: Clinic Exterior Architecture Photo (Col 5-8) -->
                <div class="lg:col-span-4 rounded-2xl overflow-hidden shadow-sm border border-slate-200/90 relative min-h-[260px] lg:min-h-auto">
                    <img 
                        src="https://images.unsplash.com/photo-1586773860418-d37222d8fce3?auto=format&fit=crop&w=1000&q=80" 
                        alt="Premier Specialist Clinic Building Exterior and Parking"
                        class="w-full h-full object-cover object-center"
                    />
                    <!-- Clinic Signage Overlay -->
                    <div class="absolute inset-0 bg-black/20 flex items-center justify-center p-4">
                        <div class="bg-white/90 backdrop-blur-sm px-4 py-2.5 rounded-lg border border-white shadow-md text-center">
                            <span class="font-editorial font-bold text-sm text-[#103d52] block">PREMIER</span>
                            <span class="text-[9px] font-semibold uppercase tracking-wider text-slate-600 block">SPECIALIST CLINIC</span>
                        </div>
                    </div>
                </div>

                <!-- Right: Map Embed Card (Col 9-12) -->
                <div class="lg:col-span-4 rounded-2xl overflow-hidden shadow-sm border border-slate-200/90 bg-slate-100 relative min-h-[260px] lg:min-h-auto">
                    <iframe 
                        title="Premier Specialist Clinic Location Map"
                        class="w-full h-full min-h-[280px] border-0"
                        loading="lazy"
                        allowfullscreen
                        referrerpolicy="no-referrer-when-downgrade"
                        src="https://maps.google.com/maps?q=4%20Jowett%20Street,%20Coomera%20QLD%204209&t=&z=16&ie=UTF8&iwloc=&output=embed"
                    ></iframe>
                </div>

            </div>
        </div>
    </section>

</div>
@endsection
