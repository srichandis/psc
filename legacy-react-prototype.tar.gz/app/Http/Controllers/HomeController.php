<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Show the Premier Specialist Clinic homepage.
     */
    public function index()
    {
        $specialists = [
            [
                'id' => 'dr-sadasivan',
                'name' => 'Dr Sadasivan',
                'qualifications' => 'MBBS, MRCPsych (UK), FRANZCP',
                'role' => 'Consultant Psychiatrist – Adult Mental Health',
                'specialty' => 'Psychiatry',
                'image' => 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=600&q=80',
            ],
            [
                'id' => 'dr-sarah-thomas',
                'name' => 'Dr Sarah Tanusha Thomas',
                'qualifications' => 'MBBS, MMed (Clin Epi), FRACP',
                'role' => 'Neurologist – Stroke & Cognitive Neurology',
                'specialty' => 'Neurology',
                'image' => 'https://images.unsplash.com/photo-1594824813591-628d052b6623?auto=format&fit=crop&w=600&q=80',
            ],
            [
                'id' => 'dr-subakumar',
                'name' => 'Dr Subakumar',
                'qualifications' => 'MBBS, MD, FRACP',
                'role' => 'Endocrinologist',
                'specialty' => 'Endocrinology',
                'image' => 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=600&q=80',
            ],
            [
                'id' => 'dr-thomas-titus',
                'name' => 'Dr Thomas Titus',
                'qualifications' => 'MBBS, MD, MRCP, D.Phil, FRACP',
                'role' => 'Nephrologist',
                'specialty' => 'Nephrology',
                'image' => 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&w=600&q=80',
            ],
            [
                'id' => 'dr-harish-venugopal',
                'name' => 'Dr Harish Venugopal',
                'qualifications' => 'MBBS, FRACP',
                'role' => 'Endocrinologist',
                'specialty' => 'Endocrinology',
                'image' => 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&w=600&q=80',
            ],
            [
                'id' => 'gagandeep-singh',
                'name' => 'Gagandeep Singh',
                'qualifications' => 'Registered Psychologist',
                'role' => 'Psychology',
                'specialty' => 'Psychology',
                'image' => 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
            ],
        ];

        return view('home', compact('specialists'));
    }

    /**
     * Store patient appointment inquiry.
     */
    public function storeAppointment(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:50',
            'email' => 'nullable|email|max:255',
            'specialty' => 'required|string',
            'referral' => 'required|in:yes,pending,no',
            'notes' => 'nullable|string|max:1000',
        ]);

        // Process appointment request notification to reception
        return back()->with('success', 'Thank you. Our reception team will contact you shortly to confirm your booking.');
    }
}
