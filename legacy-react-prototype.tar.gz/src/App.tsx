/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { SpecialistsSection } from './components/SpecialistsSection';
import { SpecialtiesSection } from './components/SpecialtiesSection';
import { VisitProcessSection } from './components/VisitProcessSection';
import { LocationSection } from './components/LocationSection';
import { Footer } from './components/Footer';
import { AppointmentModal } from './components/AppointmentModal';
import { DoctorProfileModal } from './components/DoctorProfileModal';
import { SpecialtyDetailModal } from './components/SpecialtyDetailModal';
import { LaravelBladeExplorer } from './components/LaravelBladeExplorer';
import { Specialist, Specialty } from './types';

export default function App() {
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [selectedSpecialist, setSelectedSpecialist] = useState<Specialist | null>(null);
  const [selectedSpecialty, setSelectedSpecialty] = useState<Specialty | null>(null);
  const [preselectedSpecialistId, setPreselectedSpecialistId] = useState<string | undefined>();
  const [activeSection, setActiveSection] = useState('home');
  const [isBladeView, setIsBladeView] = useState(false);

  // Scroll spy to keep active navbar link updated
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'specialists', 'specialties', 'visit-process', 'location'];
      const scrollPos = window.scrollY + 200;

      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleOpenBooking = (specialistId?: string) => {
    setPreselectedSpecialistId(specialistId);
    setIsBookingOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#f4f8fa] text-slate-800 flex flex-col selection:bg-[#103d52] selection:text-white">
      {/* Top Dynamic Navigation Bar */}
      <Navbar
        onOpenBooking={() => handleOpenBooking()}
        activeSection={activeSection}
        isBladeView={isBladeView}
        onToggleBladeView={() => setIsBladeView(!isBladeView)}
      />

      {/* Main Content Area */}
      <main className="flex-grow">
        {isBladeView ? (
          /* Laravel Blade Template Inspector & Code Explorer */
          <LaravelBladeExplorer onBackToPreview={() => setIsBladeView(false)} />
        ) : (
          /* Live Interactive Clinic Homepage */
          <div className="space-y-16 sm:space-y-24">
            {/* Hero Section */}
            <Hero onOpenBooking={() => handleOpenBooking()} />

            {/* Meet Our Specialists Section */}
            <SpecialistsSection
              onSelectSpecialist={(spec) => setSelectedSpecialist(spec)}
            />

            {/* Comprehensive Specialist Care Section */}
            <SpecialtiesSection
              onSelectSpecialty={(spec) => setSelectedSpecialty(spec)}
            />

            {/* A Simple Appointment Process Stepper */}
            <VisitProcessSection
              onOpenBooking={() => handleOpenBooking()}
            />

            {/* Our Location & Map Embed */}
            <LocationSection />
          </div>
        )}
      </main>

      {/* Site Footer */}
      <Footer onOpenBooking={() => handleOpenBooking()} />

      {/* Appointment Booking Modal */}
      <AppointmentModal
        isOpen={isBookingOpen}
        onClose={() => {
          setIsBookingOpen(false);
          setPreselectedSpecialistId(undefined);
        }}
        preselectedSpecialistId={preselectedSpecialistId}
      />

      {/* Specialist Doctor Profile Modal */}
      <DoctorProfileModal
        specialist={selectedSpecialist}
        onClose={() => setSelectedSpecialist(null)}
        onBookWithDoctor={(specialistId) => handleOpenBooking(specialistId)}
      />

      {/* Specialty Department Detail Modal */}
      <SpecialtyDetailModal
        specialty={selectedSpecialty}
        onClose={() => setSelectedSpecialty(null)}
        onBookSpecialty={(specialtyName) => {
          handleOpenBooking();
        }}
      />
    </div>
  );
}
