import { BladeFileTemplate } from '../types';

export const LARAVEL_BLADE_FILES: BladeFileTemplate[] = [
  {
    path: 'resources/views/layouts/app.blade.php',
    name: 'app.blade.php',
    type: 'layout',
    description: 'Main master layout containing HTML5 structure, Google Fonts, Tailwind Vite integration, dynamic navbar and footer includes.',
    code: `<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="scroll-smooth">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Premier Specialist Clinic | Specialist Care with a Personal Approach')</title>
    <meta name="description" content="@yield('meta_description', 'Expert medical care across neurology, psychiatry, psychology, endocrinology and nephrology in Coomera QLD.')">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&family=Newsreader:ital,opsz,wght@0,6..72,400..700;1,6..72,400..700&family=Plus+Jakarta+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">

    <!-- Tailwind CSS & Vite -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <style>
        .font-editorial { font-family: 'Newsreader', Georgia, serif; }
        .font-script { font-family: 'Caveat', cursive; }
        [x-cloak] { display: none !important; }
    </style>
</head>
<body class="bg-[#f4f8fa] text-slate-800 antialiased font-sans flex flex-col min-h-screen">
    <!-- Dynamic Navigation Bar Component -->
    <x-navbar />

    <!-- Main Content -->
    <main class="flex-grow">
        @yield('content')
    </main>

    <!-- Global Appointment Modal Component -->
    @include('components.appointment-modal')

    <!-- Footer Component -->
    <x-footer />
</body>
</html>`
  },
  {
    path: 'resources/views/components/navbar.blade.php',
    name: 'navbar.blade.php',
    type: 'component',
    description: 'Dynamic navigation bar with sticky scroll effect, active route indicator, mobile menu drawer, phone dialer, and booking CTA.',
    code: `@props(['active' => 'home'])

<nav 
    x-data="{ 
        scrolled: false, 
        mobileOpen: false,
        specialtiesDropdown: false 
    }"
    x-init="window.addEventListener('scroll', () => { scrolled = window.scrollY > 20 })"
    :class="scrolled ? 'bg-white/95 backdrop-blur-md shadow-sm border-b border-slate-100 py-3' : 'bg-transparent py-4 sm:py-5 border-b border-slate-200/60'"
    class="sticky top-0 z-50 transition-all duration-300 w-full"
    id="main-nav"
>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between">
            <!-- Brand Logo -->
            <a href="{{ route('home') ?? '#' }}" class="flex items-center gap-3.5 group">
                <div class="w-10 h-10 sm:w-11 sm:h-11 relative flex-shrink-0 text-[#103d52] group-hover:scale-105 transition-transform">
                    <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-full h-full">
                        <path d="M72 18C72 18 42 22 28 50C16 74 32 88 44 86C60 84 76 66 82 42C86 26 72 18 72 18Z" fill="#103D52" opacity="0.95"/>
                        <path d="M48 30C48 30 24 38 18 60C14 74 24 82 34 80C46 76 56 62 60 48C62 38 48 30 48 30Z" fill="#247871" opacity="0.9"/>
                    </svg>
                </div>
                <div class="flex flex-col">
                    <span class="font-editorial text-2xl sm:text-3xl font-bold tracking-tight text-[#103d52] leading-none">PREMIER</span>
                    <span class="text-[10px] sm:text-[11px] font-semibold tracking-[0.24em] text-[#103d52] uppercase leading-tight mt-0.5">SPECIALIST CLINIC</span>
                    <span class="text-[11px] sm:text-xs italic text-[#227066] font-editorial leading-none mt-0.5">Expert care for a healthier tomorrow</span>
                </div>
            </a>

            <!-- Desktop Navigation Links -->
            <div class="hidden lg:flex items-center space-x-7">
                <a href="#home" class="py-2 text-sm font-semibold text-[#103d52] border-b-2 border-[#247871]">Home</a>
                <a href="#specialists" class="py-2 text-sm font-medium text-slate-700 hover:text-[#103d52] transition-colors">Our Specialists</a>
                <a href="#specialties" class="py-2 text-sm font-medium text-slate-700 hover:text-[#103d52] transition-colors">Specialties</a>
                <a href="#visit-process" class="py-2 text-sm font-medium text-slate-700 hover:text-[#103d52] transition-colors">For Patients</a>
                <a href="#location" class="py-2 text-sm font-medium text-slate-700 hover:text-[#103d52] transition-colors">About Us</a>
                <a href="#location" class="py-2 text-sm font-medium text-slate-700 hover:text-[#103d52] transition-colors">Contact</a>
            </div>

            <!-- Right Actions: Phone + Book CTA -->
            <div class="hidden sm:flex items-center space-x-5">
                <a href="tel:0755000536" class="inline-flex items-center gap-2 text-sm font-semibold text-[#103d52] hover:text-[#247871]">
                    <div class="w-7 h-7 rounded-full bg-emerald-50 text-[#247871] flex items-center justify-center">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                    </div>
                    <span>(07) 5500 0536</span>
                </a>
                <button type="button" @click="$dispatch('open-appointment-modal')" class="px-5 py-2.5 text-sm font-medium text-white bg-[#103d52] hover:bg-[#0c2b3a] rounded-md transition-all shadow-sm">
                    Book an Appointment
                </button>
            </div>

            <!-- Mobile Menu Button -->
            <div class="flex items-center lg:hidden">
                <button type="button" @click="mobileOpen = !mobileOpen" class="p-2 text-slate-700 rounded-md">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>
            </div>
        </div>
    </div>
</nav>`
  },
  {
    path: 'resources/views/home.blade.php',
    name: 'home.blade.php',
    type: 'view',
    description: 'The primary homepage Blade view with Hero, Specialists grid, Specialties cards, 4-step visit stepper, and Coomera location map.',
    code: `@extends('layouts.app')

@section('title', 'Premier Specialist Clinic | Specialist Care with a Personal Approach')

@section('content')
<div id="home" class="space-y-16 sm:space-y-24">
    <!-- Hero Section -->
    <section class="pt-6 sm:pt-10 lg:pt-14">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
                <div class="lg:col-span-7 space-y-6">
                    <h1 class="font-editorial text-4xl sm:text-5xl lg:text-6xl font-bold text-[#103d52] leading-[1.12]">
                        Specialist care<br>with a personal approach
                    </h1>
                    <p class="text-base sm:text-lg text-slate-600 max-w-xl">
                        Expert medical care across neurology, psychiatry, psychology, endocrinology and nephrology.
                    </p>
                    <div class="flex flex-wrap items-center gap-3.5 pt-1">
                        <button type="button" @click="$dispatch('open-appointment-modal')" class="px-6 py-3.5 rounded-md text-sm font-semibold text-white bg-[#103d52] hover:bg-[#0c2b3a] transition-all shadow-sm">
                            Book an Appointment &rarr;
                        </button>
                        <a href="tel:0755000536" class="px-5 py-3.5 rounded-md text-sm font-semibold text-[#103d52] bg-white border border-[#103d52]/40 hover:bg-slate-50 transition-all">
                            Call (07) 5500 0536
                        </a>
                    </div>
                    <div class="flex items-start gap-3.5 pt-4 text-xs sm:text-sm text-slate-600">
                        <div class="w-8 h-8 rounded-full bg-[#103d52]/10 text-[#103d52] flex items-center justify-center flex-shrink-0 mt-0.5">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                        </div>
                        <div>
                            <p class="font-bold text-[#103d52]">4 Jowett Street, Coomera QLD 4209</p>
                            <p class="text-xs text-slate-500">Free on-site parking for patients, including accessible spaces.</p>
                        </div>
                    </div>
                </div>

                <div class="lg:col-span-5 relative">
                    <div class="relative rounded-2xl overflow-hidden shadow-lg aspect-[5/4]">
                        <img src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1200&q=80" alt="Consultation" class="w-full h-full object-cover">
                        <div class="absolute bottom-4 right-5 text-right font-script text-2xl text-white drop-shadow-md">
                            People.<br>Specialist care.<br>Brighter tomorrows.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Our Specialists Section -->
    <section id="specialists">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex flex-col md:flex-row md:items-end justify-between mb-8">
                <div>
                    <span class="text-xs font-bold uppercase tracking-[0.2em] text-[#247871]">OUR SPECIALISTS</span>
                    <h2 class="font-editorial text-3xl sm:text-4xl font-bold text-[#103d52]">Meet Our Specialists</h2>
                    <p class="text-sm text-slate-600 max-w-2xl mt-1">Our multidisciplinary team provides specialist assessment and care across a range of conditions.</p>
                </div>
                <a href="#specialists" class="text-xs font-bold text-[#103d52]">View All Specialists &rarr;</a>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-5">
                @foreach($specialists as $specialist)
                    <x-specialist-card :name="$specialist['name']" :qualifications="$specialist['qualifications']" :role="$specialist['role']" :image="$specialist['image']" />
                @endforeach
            </div>
        </div>
    </section>
</div>
@endsection`
  },
  {
    path: 'resources/views/components/footer.blade.php',
    name: 'footer.blade.php',
    type: 'component',
    description: 'Footer blade component with full navigation links, patient info, and contact info.',
    code: `<footer class="bg-[#103d52] text-slate-200 mt-20 pt-16 pb-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-14 border-b border-slate-700/60">
            <div>
                <span class="font-editorial text-2xl font-bold text-white block">PREMIER</span>
                <span class="text-[10px] font-semibold tracking-[0.22em] text-teal-200 uppercase block">SPECIALIST CLINIC</span>
                <p class="text-xs text-slate-300 pt-3">Specialist care across neurology, psychiatry, psychology, endocrinology and nephrology.</p>
            </div>
            <div>
                <h4 class="text-sm font-semibold uppercase mb-4 text-white">Quick Links</h4>
                <ul class="space-y-2 text-xs text-slate-300">
                    <li><a href="#home">Home</a></li>
                    <li><a href="#specialists">Our Specialists</a></li>
                    <li><a href="#specialties">Specialties</a></li>
                    <li><a href="#visit-process">For Patients</a></li>
                </ul>
            </div>
            <div>
                <h4 class="text-sm font-semibold uppercase mb-4 text-white">Get In Touch</h4>
                <p class="text-xs text-slate-300">4 Jowett Street, Coomera QLD 4209</p>
                <p class="text-xs text-slate-300 mt-2">(07) 5500 0536</p>
            </div>
        </div>
        <div class="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
            <p>&copy; {{ date('Y') }} Premier Specialist Clinic. All rights reserved.</p>
            <p class="font-script text-xl text-teal-100">People. Specialist care. Brighter tomorrows.</p>
        </div>
    </div>
</footer>`
  },
  {
    path: 'routes/web.php',
    name: 'web.php',
    type: 'route',
    description: 'Web routes definition registering GET / for HomeController@index.',
    code: `<?php

use Illuminate\\Support\\Facades\\Route;
use App\\Http\\Controllers\\HomeController;

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::post('/appointments', [HomeController::class, 'storeAppointment'])->name('appointments.store');`
  },
  {
    path: 'app/Http/Controllers/HomeController.php',
    name: 'HomeController.php',
    type: 'controller',
    description: 'Controller providing doctors and specialties data to home.blade.php view.',
    code: `<?php

namespace App\\Http\\Controllers;

use Illuminate\\Http\\Request;

class HomeController extends Controller
{
    public function index()
    {
        $specialists = [
            ['id' => 'dr-sadasivan', 'name' => 'Dr Sadasivan', 'qualifications' => 'MBBS, MRCPsych (UK), FRANZCP', 'role' => 'Consultant Psychiatrist – Adult Mental Health', 'image' => 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=600&q=80'],
            ['id' => 'dr-sarah-thomas', 'name' => 'Dr Sarah Tanusha Thomas', 'qualifications' => 'MBBS, MMed (Clin Epi), FRACP', 'role' => 'Neurologist – Stroke & Cognitive Neurology', 'image' => 'https://images.unsplash.com/photo-1594824813591-628d052b6623?auto=format&fit=crop&w=600&q=80'],
            ['id' => 'dr-subakumar', 'name' => 'Dr Subakumar', 'qualifications' => 'MBBS, MD, FRACP', 'role' => 'Endocrinologist', 'image' => 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=600&q=80'],
            ['id' => 'dr-thomas-titus', 'name' => 'Dr Thomas Titus', 'qualifications' => 'MBBS, MD, MRCP, D.Phil, FRACP', 'role' => 'Nephrologist', 'image' => 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&w=600&q=80'],
            ['id' => 'dr-harish-venugopal', 'name' => 'Dr Harish Venugopal', 'qualifications' => 'MBBS, FRACP', 'role' => 'Endocrinologist', 'image' => 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&w=600&q=80'],
            ['id' => 'gagandeep-singh', 'name' => 'Gagandeep Singh', 'qualifications' => 'Registered Psychologist', 'role' => 'Psychology', 'image' => 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80'],
        ];

        return view('home', compact('specialists'));
    }
}`
  }
];
