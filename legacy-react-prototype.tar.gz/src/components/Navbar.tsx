import React, { useState, useEffect } from 'react';
import { Phone, ChevronDown, Menu, X, Code2, Sparkles, ExternalLink } from 'lucide-react';
import { CLINIC_INFO, SPECIALTIES } from '../data/clinicData';

interface NavbarProps {
  onOpenBooking: () => void;
  activeSection: string;
  isBladeView: boolean;
  onToggleBladeView: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenBooking,
  activeSection,
  isBladeView,
  onToggleBladeView,
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [specialtiesOpen, setSpecialtiesOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home', id: 'home' },
    { name: 'Our Specialists', href: '#specialists', id: 'specialists' },
    { name: 'Specialties', href: '#specialties', id: 'specialties', hasDropdown: true },
    { name: 'For Patients', href: '#visit-process', id: 'visit-process' },
    { name: 'About Us', href: '#location', id: 'about' },
    { name: 'Contact', href: '#location', id: 'contact' },
  ];

  return (
    <>
      <header
        className={`sticky top-0 z-40 w-full transition-all duration-300 ${
          scrolled
            ? 'bg-white/95 backdrop-blur-md shadow-sm border-b border-slate-200/80 py-3'
            : 'bg-white/80 backdrop-blur-sm py-4 sm:py-5 border-b border-slate-200/50'
        }`}
        id="main-navigation-bar"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            
            {/* Brand Logo & Tagline */}
            <a
              href="#home"
              className="flex items-center gap-3.5 group focus:outline-none"
              id="clinic-brand-logo"
            >
              {/* Dual Eucalyptus Leaf Logo */}
              <div className="w-10 h-10 sm:w-11 sm:h-11 relative flex-shrink-0 text-[#103d52] group-hover:scale-105 transition-transform duration-200">
                <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full drop-shadow-sm">
                  {/* Primary leaf */}
                  <path
                    d="M72 18C72 18 42 22 28 50C16 74 32 88 44 86C60 84 76 66 82 42C86 26 72 18 72 18Z"
                    fill="#103D52"
                    opacity="0.96"
                  />
                  <path
                    d="M30 68C42 54 58 40 76 28"
                    stroke="#ffffff"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    opacity="0.5"
                  />
                  {/* Accent sage leaf */}
                  <path
                    d="M48 30C48 30 24 38 18 60C14 74 24 82 34 80C46 76 56 62 60 48C62 38 48 30 48 30Z"
                    fill="#247871"
                    opacity="0.92"
                  />
                  <path
                    d="M22 68C32 58 42 48 54 40"
                    stroke="#ffffff"
                    strokeWidth="2"
                    strokeLinecap="round"
                    opacity="0.45"
                  />
                </svg>
              </div>

              {/* Text Hierarchy */}
              <div className="flex flex-col">
                <span className="font-editorial text-2xl sm:text-[28px] font-bold tracking-tight text-[#103d52] leading-none">
                  PREMIER
                </span>
                <span className="text-[10px] sm:text-[11px] font-semibold tracking-[0.24em] text-[#103d52] uppercase leading-tight mt-0.5">
                  SPECIALIST CLINIC
                </span>
                <span className="text-[11px] sm:text-xs italic text-[#227066] font-editorial leading-none mt-0.5 font-normal">
                  Expert care for a healthier tomorrow
                </span>
              </div>
            </a>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center space-x-7" aria-label="Main Navigation">
              {navLinks.map((link) => {
                const isActive = activeSection === link.id || (link.id === 'home' && !activeSection);

                if (link.hasDropdown) {
                  return (
                    <div
                      key={link.name}
                      className="relative"
                      onMouseEnter={() => setSpecialtiesOpen(true)}
                      onMouseLeave={() => setSpecialtiesOpen(false)}
                    >
                      <a
                        href={link.href}
                        className={`inline-flex items-center gap-1 py-2 text-sm font-medium tracking-wide transition-colors ${
                          isActive
                            ? 'text-[#103d52] font-semibold'
                            : 'text-slate-700 hover:text-[#103d52]'
                        }`}
                        id={`nav-link-${link.id}`}
                      >
                        <span>{link.name}</span>
                        <ChevronDown
                          className={`w-3.5 h-3.5 transition-transform duration-200 ${
                            specialtiesOpen ? 'rotate-180 text-[#247871]' : 'text-slate-400'
                          }`}
                        />
                      </a>

                      {/* Dropdown Menu */}
                      {specialtiesOpen && (
                        <div className="absolute top-full left-0 w-64 pt-2 z-50 animate-fadeIn">
                          <div className="bg-white rounded-xl shadow-xl border border-slate-100 p-2 ring-1 ring-black/5">
                            <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-[#247871]">
                              Clinical Specialties
                            </div>
                            {SPECIALTIES.map((spec) => (
                              <a
                                key={spec.id}
                                href={`#specialties`}
                                onClick={() => setSpecialtiesOpen(false)}
                                className="flex flex-col px-3 py-2 rounded-lg hover:bg-slate-50 transition-colors group"
                              >
                                <span className="text-xs font-semibold text-slate-800 group-hover:text-[#103d52]">
                                  {spec.name}
                                </span>
                                <span className="text-[11px] text-slate-500 line-clamp-1">
                                  {spec.shortDesc}
                                </span>
                              </a>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                }

                return (
                  <a
                    key={link.name}
                    href={link.href}
                    className={`relative py-2 text-sm tracking-wide transition-all ${
                      isActive
                        ? 'text-[#103d52] font-semibold'
                        : 'text-slate-700 hover:text-[#103d52] font-medium'
                    }`}
                    id={`nav-link-${link.id}`}
                  >
                    {link.name}
                    {isActive && (
                      <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#247871] rounded-full" />
                    )}
                  </a>
                );
              })}
            </nav>

            {/* Right Action Controls: Phone + Booking Button + Blade Mode Switch */}
            <div className="flex items-center gap-3 sm:gap-4">
              
              {/* Blade Inspector Toggle Button */}
              <button
                type="button"
                onClick={onToggleBladeView}
                className={`inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-full border transition-all ${
                  isBladeView
                    ? 'bg-[#247871] text-white border-[#247871] shadow-sm'
                    : 'bg-emerald-50/70 text-[#103d52] border-emerald-200/80 hover:bg-emerald-100/70'
                }`}
                title="View Laravel Blade templates and source code"
                id="blade-toggle-button"
              >
                <Code2 className="w-3.5 h-3.5 text-[#247871]" />
                <span className="hidden md:inline font-semibold">
                  {isBladeView ? 'View Live Site' : 'Blade Files'}
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.2 bg-white/40 rounded">
                  Laravel
                </span>
              </button>

              {/* Reception Phone Link */}
              <a
                href={`tel:${CLINIC_INFO.phoneClean}`}
                className="hidden sm:inline-flex items-center gap-2 text-sm font-semibold text-[#103d52] hover:text-[#247871] transition-colors px-2 py-1.5 rounded-lg group"
                id="header-phone-cta"
              >
                <div className="w-7 h-7 rounded-full bg-emerald-50 text-[#247871] group-hover:bg-[#247871] group-hover:text-white transition-colors flex items-center justify-center">
                  <Phone className="w-3.5 h-3.5" />
                </div>
                <span>{CLINIC_INFO.phone}</span>
              </a>

              {/* Book Appointment CTA */}
              <button
                type="button"
                onClick={onOpenBooking}
                className="inline-flex items-center justify-center px-4 sm:px-5 py-2 sm:py-2.5 text-xs sm:text-sm font-semibold text-white bg-[#103d52] hover:bg-[#0c2b3a] rounded-md transition-all shadow-sm hover:shadow active:scale-[0.98]"
                id="header-book-appointment-button"
              >
                Book an Appointment
              </button>

              {/* Mobile Hamburger Button */}
              <button
                type="button"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-slate-700 hover:text-[#103d52] hover:bg-slate-100 rounded-lg lg:hidden"
                aria-label="Toggle navigation menu"
                id="mobile-menu-button"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Dropdown Menu Drawer */}
        {mobileMenuOpen && (
          <div
            className="lg:hidden bg-white border-b border-slate-200 px-4 pt-3 pb-6 space-y-3 shadow-xl animate-fadeIn"
            id="mobile-navigation-drawer"
          >
            <div className="space-y-1">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`block px-3 py-2.5 rounded-lg text-sm font-medium ${
                    activeSection === link.id
                      ? 'bg-[#103d52]/5 text-[#103d52] font-semibold'
                      : 'text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {link.name}
                </a>
              ))}
            </div>

            <div className="pt-3 border-t border-slate-100 space-y-2">
              <a
                href={`tel:${CLINIC_INFO.phoneClean}`}
                className="flex items-center justify-center gap-2 w-full py-2.5 text-sm font-semibold text-[#103d52] bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200"
              >
                <Phone className="w-4 h-4 text-[#247871]" />
                <span>Call {CLINIC_INFO.phone}</span>
              </a>

              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenBooking();
                }}
                className="w-full py-2.5 text-sm font-semibold text-center text-white bg-[#103d52] hover:bg-[#0c2b3a] rounded-lg shadow"
              >
                Book an Appointment
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
