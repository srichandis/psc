import React from 'react';
import { ArrowRight, Phone, MapPin, Sparkles } from 'lucide-react';
import { CLINIC_INFO } from '../data/clinicData';

interface HeroProps {
  onOpenBooking: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenBooking }) => {
  return (
    <section className="relative overflow-hidden pt-6 sm:pt-10 lg:pt-14 pb-8" id="home">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Hero Column */}
          <div className="lg:col-span-7 space-y-6 sm:space-y-8 z-10">
            <div className="space-y-4 max-w-2xl">
              <h1 className="font-editorial text-4xl sm:text-5xl lg:text-[58px] font-bold tracking-tight text-[#103d52] leading-[1.12]">
                Specialist care<br />
                with a personal approach
              </h1>
              <p className="text-base sm:text-lg text-slate-600 font-normal leading-relaxed max-w-xl">
                Expert medical care across neurology, psychiatry, psychology, endocrinology and nephrology.
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3.5 pt-1">
              <button
                type="button"
                onClick={onOpenBooking}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-md text-sm font-semibold text-white bg-[#103d52] hover:bg-[#0c2b3a] transition-all shadow-sm hover:shadow active:scale-[0.98] group"
                id="hero-book-appointment-button"
              >
                <span>Book an Appointment</span>
                <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </button>

              <a
                href={`tel:${CLINIC_INFO.phoneClean}`}
                className="inline-flex items-center gap-2 px-5 py-3.5 rounded-md text-sm font-semibold text-[#103d52] bg-white border border-[#103d52]/40 hover:bg-slate-50 transition-all active:scale-[0.98]"
                id="hero-call-phone-button"
              >
                <Phone className="w-4 h-4 text-[#247871]" />
                <span>Call {CLINIC_INFO.phone}</span>
              </a>
            </div>

            {/* Address and Parking Banner */}
            <div className="flex items-start gap-3.5 pt-4 max-w-xl text-xs sm:text-sm text-slate-600">
              <div className="w-8 h-8 rounded-full bg-[#103d52]/10 text-[#103d52] flex items-center justify-center flex-shrink-0 mt-0.5">
                <MapPin className="w-4 h-4 text-[#103d52]" />
              </div>
              <div>
                <p className="font-bold text-[#103d52]">{CLINIC_INFO.address}</p>
                <p className="text-xs text-slate-500 mt-0.5">
                  {CLINIC_INFO.parkingInfo.split('.')[0]}.
                </p>
              </div>
            </div>
          </div>

          {/* Right Hero Image with Signature Script Slogan */}
          <div className="lg:col-span-5 relative mt-4 lg:mt-0">
            <div className="relative rounded-2xl overflow-hidden shadow-lg border border-white/80 aspect-[5/4] sm:aspect-[4/3] lg:aspect-[5/4] group">
              <img
                src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1200&q=80"
                alt="Premier Specialist Clinic Consultation"
                className="w-full h-full object-cover object-center group-hover:scale-[1.02] transition-transform duration-700"
              />
              
              {/* Subtle gradient vignette */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#103d52]/60 via-transparent to-transparent pointer-events-none" />

              {/* Handwritten Script Signature in bottom right */}
              <div className="absolute bottom-4 right-5 text-right pointer-events-none select-none">
                <p className="font-script text-2xl sm:text-3xl text-white font-normal drop-shadow-md leading-tight tracking-wide">
                  People.<br />
                  Specialist care.<br />
                  Brighter tomorrows.
                </p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
