import React from 'react';
import { X, CheckCircle2, ArrowRight, ShieldCheck, Stethoscope } from 'lucide-react';
import { Specialty } from '../types';
import { SPECIALISTS } from '../data/clinicData';

interface SpecialtyDetailModalProps {
  specialty: Specialty | null;
  onClose: () => void;
  onBookSpecialty: (specialtyName: string) => void;
}

export const SpecialtyDetailModal: React.FC<SpecialtyDetailModalProps> = ({
  specialty,
  onClose,
  onBookSpecialty,
}) => {
  if (!specialty) return null;

  const relevantDoctors = SPECIALISTS.filter(s => s.specialty === specialty.name);

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6"
      role="dialog"
      aria-modal="true"
    >
      <div className="relative bg-white rounded-2xl shadow-2xl border border-slate-100 max-w-2xl w-full overflow-hidden animate-scaleIn">
        
        {/* Header */}
        <div className="bg-[#103d52] p-6 text-white relative">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-1 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <span className="text-[10px] font-bold uppercase tracking-widest text-teal-200 block mb-1">
            Clinical Specialty
          </span>
          <h3 className="font-editorial text-2xl sm:text-3xl font-bold">
            {specialty.name}
          </h3>
          <p className="text-xs text-teal-100 max-w-xl mt-1 leading-relaxed">
            {specialty.shortDesc}
          </p>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 space-y-6 text-slate-700 text-xs sm:text-sm">
          {/* Overview */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Department Overview
            </h4>
            <p className="text-slate-600 leading-relaxed">
              {specialty.fullDesc}
            </p>
          </div>

          {/* Conditions Treated */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Key Conditions Managed
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {specialty.conditions.map((item) => (
                <div key={item} className="flex items-start gap-2 text-xs text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-[#247871] flex-shrink-0 mt-0.5" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Diagnostic Services */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Diagnostic & Clinical Services
            </h4>
            <div className="flex flex-wrap gap-2">
              {specialty.diagnosticServices.map((service) => (
                <span
                  key={service}
                  className="bg-slate-100 text-slate-700 px-3 py-1 rounded-md text-xs font-medium border border-slate-200"
                >
                  {service}
                </span>
              ))}
            </div>
          </div>

          {/* Associated Specialists */}
          {relevantDoctors.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Department Specialists
              </h4>
              <div className="space-y-2">
                {relevantDoctors.map((doc) => (
                  <div
                    key={doc.id}
                    className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200/80"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={doc.image}
                        alt={doc.name}
                        className="w-10 h-10 rounded-full object-cover border border-slate-200"
                      />
                      <div>
                        <p className="text-xs font-bold text-[#103d52]">{doc.name}</p>
                        <p className="text-[11px] text-slate-500">{doc.role}</p>
                      </div>
                    </div>
                    <span className="text-[11px] text-[#247871] font-semibold">
                      {doc.consultingDays}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Action Footer */}
          <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Close
            </button>
            <button
              type="button"
              onClick={() => {
                onClose();
                onBookSpecialty(specialty.name);
              }}
              className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-lg bg-[#103d52] hover:bg-[#0c2b3a] text-white text-xs font-semibold shadow-sm transition-all"
            >
              <span>Request Consultation</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
