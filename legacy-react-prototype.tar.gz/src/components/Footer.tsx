import React from 'react';
import { MapPin, Phone, Mail } from 'lucide-react';
import { CLINIC_INFO } from '../data/clinicData';

interface FooterProps {
  onOpenBooking: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenBooking }) => {
  return (
    <footer className="bg-[#103d52] text-slate-200 mt-20 pt-16 pb-12" id="site-footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main 4-Column Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-12 pb-14 border-b border-slate-700/60">
          
          {/* Brand & Mission Column */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 relative flex-shrink-0 text-white">
                <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
                  <path
                    d="M72 18C72 18 42 22 28 50C16 74 32 88 44 86C60 84 76 66 82 42C86 26 72 18 72 18Z"
                    fill="#ffffff"
                    opacity="0.95"
                  />
                  <path
                    d="M48 30C48 30 24 38 18 60C14 74 24 82 34 80C46 76 56 62 60 48C62 38 48 30 48 30Z"
                    fill="#38b2ac"
                    opacity="0.9"
                  />
                </svg>
              </div>
              <div>
                <span className="font-editorial text-2xl font-bold tracking-tight text-white block leading-none">
                  PREMIER
                </span>
                <span className="text-[10px] font-semibold tracking-[0.22em] text-teal-200 uppercase block mt-0.5">
                  SPECIALIST CLINIC
                </span>
                <span className="text-xs italic text-teal-100 font-editorial block mt-0.5">
                  {CLINIC_INFO.tagline}
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed pt-2 pr-4">
              Specialist care across neurology, psychiatry, psychology, endocrinology and nephrology.
            </p>
          </div>

          {/* Quick Links Column */}
          <div>
            <h4 className="text-sm font-semibold tracking-wider text-white uppercase mb-4">
              Quick Links
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-300">
              <li>
                <a href="#home" className="hover:text-teal-200 transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="#specialists" className="hover:text-teal-200 transition-colors">
                  Our Specialists
                </a>
              </li>
              <li>
                <a href="#specialties" className="hover:text-teal-200 transition-colors">
                  Specialties
                </a>
              </li>
              <li>
                <a href="#visit-process" className="hover:text-teal-200 transition-colors">
                  For Patients
                </a>
              </li>
              <li>
                <a href="#location" className="hover:text-teal-200 transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="#location" className="hover:text-teal-200 transition-colors">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Patient Information Column */}
          <div>
            <h4 className="text-sm font-semibold tracking-wider text-white uppercase mb-4">
              Patient Information
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-300">
              <li>
                <button
                  type="button"
                  onClick={onOpenBooking}
                  className="hover:text-teal-200 transition-colors text-left"
                >
                  Appointments
                </button>
              </li>
              <li>
                <a href="#visit-process" className="hover:text-teal-200 transition-colors">
                  Referral Information
                </a>
              </li>
              <li>
                <a href="#location" className="hover:text-teal-200 transition-colors">
                  Parking
                </a>
              </li>
              <li>
                <a href="#visit-process" className="hover:text-teal-200 transition-colors">
                  FAQs
                </a>
              </li>
              <li>
                <span className="text-slate-400">
                  Privacy Policy
                </span>
              </li>
            </ul>
          </div>

          {/* Get In Touch Column */}
          <div>
            <h4 className="text-sm font-semibold tracking-wider text-white uppercase mb-4">
              Get In Touch
            </h4>
            <ul className="space-y-3.5 text-xs text-slate-300">
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-teal-300 flex-shrink-0 mt-0.5" />
                <span>
                  4 Jowett Street,<br />
                  Coomera QLD 4209
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-teal-300 flex-shrink-0" />
                <a href={`tel:${CLINIC_INFO.phoneClean}`} className="hover:text-white transition-colors">
                  {CLINIC_INFO.phone}
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-teal-300 flex-shrink-0" />
                <button
                  type="button"
                  onClick={onOpenBooking}
                  className="hover:text-white transition-colors text-left"
                >
                  Send us a message
                </button>
              </li>
            </ul>
          </div>

        </div>

        {/* Copyright & Script Signature Row */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <p>© {new Date().getFullYear()} Premier Specialist Clinic. All rights reserved.</p>
          <p className="font-script text-xl sm:text-2xl text-teal-100 tracking-wide">
            {CLINIC_INFO.scriptSignature}
          </p>
        </div>

      </div>
    </footer>
  );
};
