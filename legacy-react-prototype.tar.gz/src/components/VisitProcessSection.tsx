import React from 'react';
import { ArrowRight, FileText, Phone, Calendar, UserCheck, ChevronRight } from 'lucide-react';
import { PROCESS_STEPS, CLINIC_INFO } from '../data/clinicData';

interface VisitProcessSectionProps {
  onOpenBooking: () => void;
}

export const VisitProcessSection: React.FC<VisitProcessSectionProps> = ({ onOpenBooking }) => {
  const getIcon = (iconType: string) => {
    switch (iconType) {
      case 'file':
        return <FileText className="w-5 h-5" />;
      case 'phone':
        return <Phone className="w-5 h-5" />;
      case 'calendar':
        return <Calendar className="w-5 h-5" />;
      case 'users':
        return <UserCheck className="w-5 h-5" />;
      default:
        return <FileText className="w-5 h-5" />;
    }
  };

  return (
    <section id="visit-process" className="scroll-mt-24 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 sm:mb-12 gap-4">
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#247871] block">
              YOUR VISIT
            </span>
            <h2 className="font-editorial text-3xl sm:text-4xl font-bold text-[#103d52]">
              A Simple Appointment Process
            </h2>
          </div>

          <div>
            <button
              type="button"
              onClick={onOpenBooking}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-[#103d52] hover:text-[#247871] transition-colors whitespace-nowrap group"
              id="more-patient-info-link"
            >
              <span>More Information for Patients</span>
              <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>

        {/* Stepper Card Container */}
        <div className="bg-white/80 rounded-2xl p-6 sm:p-10 border border-slate-200/90 shadow-sm">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-4 relative">
            
            {PROCESS_STEPS.map((step, idx) => (
              <div
                key={step.number}
                className="relative flex flex-col items-center text-center group"
                id={`process-step-${step.number}`}
              >
                {/* Badges Pair: Dark Teal Number + Mint Medical Icon */}
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-12 h-12 rounded-full bg-[#103d52] text-white flex items-center justify-center font-editorial font-bold text-lg shadow-sm group-hover:bg-[#0c2b3a] transition-colors">
                    {step.number}
                  </div>

                  <div className="w-12 h-12 rounded-full bg-[#e8f3f2] text-[#247871] flex items-center justify-center border border-[#c4e2de] group-hover:scale-105 transition-transform">
                    {getIcon(step.icon)}
                  </div>
                </div>

                {/* Step Title */}
                <h3 className="font-editorial text-lg sm:text-xl font-bold text-[#103d52] mb-2">
                  {step.title}
                </h3>

                {/* Step Description */}
                <p className="text-xs text-slate-600 leading-relaxed max-w-[220px]">
                  {step.number === '02' ? (
                    <>
                      Call our friendly reception team on{' '}
                      <a
                        href={`tel:${CLINIC_INFO.phoneClean}`}
                        className="font-bold text-[#103d52] hover:underline"
                      >
                        {CLINIC_INFO.phone}
                      </a>
                      .
                    </>
                  ) : (
                    step.description
                  )}
                </p>

                {/* Connector Arrow (Visible on desktop between items) */}
                {idx < PROCESS_STEPS.length - 1 && (
                  <div className="hidden lg:flex absolute top-6 -right-5 text-slate-300 pointer-events-none items-center">
                    <ChevronRight className="w-6 h-6 text-slate-300" />
                  </div>
                )}
              </div>
            ))}

          </div>
        </div>

      </div>
    </section>
  );
};
