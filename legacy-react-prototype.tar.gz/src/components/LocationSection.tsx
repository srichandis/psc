import React from 'react';
import { MapPin, ArrowRight, Navigation, Car, Clock } from 'lucide-react';
import { CLINIC_INFO } from '../data/clinicData';

export const LocationSection: React.FC = () => {
  const googleMapsDirectionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(
    CLINIC_INFO.address
  )}`;

  return (
    <section id="location" className="scroll-mt-24 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          
          {/* Left: Location & Parking Info Card */}
          <div className="lg:col-span-4 bg-white rounded-2xl p-7 border border-slate-200/90 shadow-sm flex flex-col justify-between">
            <div className="space-y-4">
              <span className="text-[11px] font-bold uppercase tracking-[0.2em] text-[#247871] block">
                FIND US IN COOMERA
              </span>
              <h3 className="font-editorial text-2xl sm:text-3xl font-bold text-[#103d52]">
                Our Location
              </h3>

              <div className="flex items-start gap-3 text-sm text-[#103d52] font-semibold pt-1">
                <MapPin className="w-5 h-5 text-[#247871] flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-slate-900 font-bold leading-tight">{CLINIC_INFO.address}</p>
                  <p className="text-xs text-slate-500 font-normal mt-0.5">Northern Gold Coast, Queensland</p>
                </div>
              </div>

              <div className="space-y-2.5 pt-2">
                <div className="flex items-start gap-2.5 text-xs text-slate-600">
                  <Car className="w-4 h-4 text-[#247871] flex-shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    {CLINIC_INFO.parkingInfo}
                  </p>
                </div>

                <div className="flex items-start gap-2.5 text-xs text-slate-600">
                  <Clock className="w-4 h-4 text-[#247871] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-slate-700">Consultation Hours:</p>
                    <p>Monday – Friday: 8:30 am – 5:00 pm</p>
                    <p className="text-slate-500">Saturday & Sunday: Closed</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-6">
              <a
                href={googleMapsDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 w-full px-6 py-3 rounded-md text-xs font-bold text-white bg-[#103d52] hover:bg-[#0c2b3a] transition-all shadow-sm active:scale-[0.98] group"
                id="get-directions-button"
              >
                <Navigation className="w-3.5 h-3.5 transform group-hover:-translate-y-0.5 transition-transform" />
                <span>Get Directions</span>
                <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform ml-1" />
              </a>
            </div>
          </div>

          {/* Middle: Modern Clinic Exterior Photo */}
          <div className="lg:col-span-4 rounded-2xl overflow-hidden shadow-sm border border-slate-200/90 relative min-h-[280px] lg:min-h-full group">
            <img
              src="https://images.unsplash.com/photo-1586773860418-d37222d8fce3?auto=format&fit=crop&w=1000&q=80"
              alt="Premier Specialist Clinic Building Exterior"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            {/* Custom Clinic Facade Signage Badge */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-black/10 to-transparent flex items-center justify-center p-4">
              <div className="bg-white/95 backdrop-blur-md px-5 py-3 rounded-xl border border-white/80 shadow-lg text-center transform group-hover:scale-105 transition-transform">
                <div className="flex items-center justify-center gap-1.5 mb-0.5">
                  <div className="w-4 h-4 text-[#103d52]">
                    <svg viewBox="0 0 100 100" fill="currentColor">
                      <path d="M72 18C72 18 42 22 28 50C16 74 32 88 44 86C60 84 76 66 82 42C86 26 72 18 72 18Z"/>
                    </svg>
                  </div>
                  <span className="font-editorial font-bold text-base sm:text-lg text-[#103d52] tracking-wide">
                    PREMIER
                  </span>
                </div>
                <span className="text-[9px] font-bold uppercase tracking-[0.24em] text-slate-600 block">
                  SPECIALIST CLINIC
                </span>
                <span className="text-[10px] text-[#247871] italic font-editorial block mt-0.5">
                  Coomera Medical Hub
                </span>
              </div>
            </div>
          </div>

          {/* Right: Interactive Google Map Embed Card */}
          <div className="lg:col-span-4 rounded-2xl overflow-hidden shadow-sm border border-slate-200/90 bg-slate-100 relative min-h-[280px] lg:min-h-full flex flex-col">
            <div className="bg-white px-4 py-2.5 border-b border-slate-200 flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 font-semibold text-slate-800">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>Premier Specialist Clinic</span>
              </div>
              <a
                href={googleMapsDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[11px] font-semibold text-[#247871] hover:underline"
              >
                View Larger Map
              </a>
            </div>
            
            <div className="flex-grow relative">
              <iframe
                title="Premier Specialist Clinic Location Map in Coomera"
                className="w-full h-full min-h-[240px] border-0"
                loading="lazy"
                allowFullScreen
                referrerPolicy="no-referrer-when-downgrade"
                src="https://maps.google.com/maps?q=4%20Jowett%20Street,%20Coomera%20QLD%204209&t=&z=15&ie=UTF8&iwloc=&output=embed"
              />
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
