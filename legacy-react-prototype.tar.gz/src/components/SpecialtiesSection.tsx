import React from 'react';
import { ArrowRight } from 'lucide-react';
import { SPECIALTIES } from '../data/clinicData';
import { Specialty } from '../types';

interface SpecialtiesSectionProps {
  onSelectSpecialty: (specialty: Specialty) => void;
}

export const SpecialtiesSection: React.FC<SpecialtiesSectionProps> = ({ onSelectSpecialty }) => {
  const renderIcon = (iconName: Specialty['iconName']) => {
    switch (iconName) {
      case 'Brain':
        return (
          <svg className="w-11 h-11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z" />
            <path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z" />
            <path d="M12 5v13" />
            <path d="M7 11h2" />
            <path d="M15 11h2" />
          </svg>
        );
      case 'HeadProfile':
        return (
          <svg className="w-11 h-11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
            <path d="M15 2a4 4 0 0 0-4 4v1H8a3 3 0 0 0-3 3v2a3 3 0 0 0 2 2.82V16a4 4 0 0 0 4 4h1v2" />
            <circle cx="16" cy="9" r="2.5" />
            <path d="M18 14c1.5 0 3 .8 3 2.5V19" />
          </svg>
        );
      case 'PsychiatryCare':
        return (
          <svg className="w-11 h-11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 21a9 9 0 0 0 9-9c0-4.97-4.03-9-9-9s-9 4.03-9 9a9 9 0 0 0 9 9z" />
            <path d="M8 12c0-2.2 1.8-4 4-4s4 1.8 4 4" />
            <path d="M12 12v4" />
            <circle cx="12" cy="12" r="1" />
          </svg>
        );
      case 'Butterfly':
        return (
          <svg className="w-11 h-11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 15V9" />
            <path d="M8 8c-3-2-6 0-6 4s3 6 6 4c1.5-.7 3-3 4-7" />
            <path d="M16 8c3-2 6 0 6 4s-3 6-6 4c-1.5-.7-3-3-4-7" />
          </svg>
        );
      case 'Kidneys':
        return (
          <svg className="w-11 h-11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
            <path d="M7 6c-2.5 0-4.5 2.5-4.5 6s2 6.5 4.5 6.5c3 0 4-3 4-6.5S9.5 6 7 6Z" />
            <path d="M17 6c2.5 0 4.5 2.5 4.5 6s-2 6.5-4.5 6.5c-3 0-4-3-4-6.5S14.5 6 17 6Z" />
            <path d="M11 12h2" />
          </svg>
        );
      default:
        return null;
    }
  };

  return (
    <section id="specialties" className="scroll-mt-24 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 sm:mb-10 gap-4">
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#247871] block">
              OUR SPECIALTIES
            </span>
            <h2 className="font-editorial text-3xl sm:text-4xl font-bold text-[#103d52]">
              Comprehensive Specialist Care
            </h2>
          </div>

          <div>
            <a
              href="#specialties"
              className="inline-flex items-center gap-1.5 text-xs font-bold text-[#103d52] hover:text-[#247871] transition-colors whitespace-nowrap group"
              id="explore-all-specialties-link"
            >
              <span>Explore All Specialties</span>
              <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
            </a>
          </div>
        </div>

        {/* 5 Specialty Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5 sm:gap-6">
          {SPECIALTIES.map((specialty) => (
            <div
              key={specialty.id}
              className="bg-white rounded-xl p-6 border border-slate-200/90 shadow-sm hover:shadow-md hover:-translate-y-1 transition-all duration-200 flex flex-col justify-between text-center group cursor-pointer"
              onClick={() => onSelectSpecialty(specialty)}
              id={`specialty-card-${specialty.id}`}
            >
              <div>
                {/* Clean medical line icon */}
                <div className="w-16 h-16 mx-auto mb-4 text-[#247871] group-hover:text-[#103d52] group-hover:scale-105 transition-all flex items-center justify-center">
                  {renderIcon(specialty.iconName)}
                </div>

                <h3 className="font-editorial text-lg sm:text-xl font-bold text-[#103d52] mb-2 group-hover:text-[#247871] transition-colors">
                  {specialty.name}
                </h3>

                <p className="text-xs text-slate-600 leading-relaxed min-h-[54px]">
                  {specialty.shortDesc}
                </p>
              </div>

              <div className="pt-5 mt-4 border-t border-slate-100">
                <button
                  type="button"
                  className="inline-flex items-center gap-1 text-xs font-bold text-[#103d52] group-hover:text-[#247871] transition-colors"
                >
                  <span>Learn More</span>
                  <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
