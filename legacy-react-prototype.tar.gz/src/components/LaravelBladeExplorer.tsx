import React, { useState } from 'react';
import { Copy, Check, FileCode, Folder, Terminal, Download, ArrowLeft, Layers, Shield } from 'lucide-react';
import { LARAVEL_BLADE_FILES } from '../data/laravelBladeSources';
import { BladeFileTemplate } from '../types';

interface LaravelBladeExplorerProps {
  onBackToPreview: () => void;
}

export const LaravelBladeExplorer: React.FC<LaravelBladeExplorerProps> = ({ onBackToPreview }) => {
  const [selectedFile, setSelectedFile] = useState<BladeFileTemplate>(LARAVEL_BLADE_FILES[0]);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadAll = () => {
    // Create a plain text file summary or trigger individual downloads
    const content = selectedFile.code;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = selectedFile.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fadeIn" id="blade-explorer-container">
      
      {/* Top Banner Navigation */}
      <div className="bg-[#103d52] rounded-2xl text-white p-6 sm:p-8 mb-8 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="bg-[#247871] text-white text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full">
                Laravel 10 / 11 Blade Engine
              </span>
              <span className="text-xs text-teal-200">Tailwind CSS 3 / 4 Styled</span>
            </div>
            <h1 className="font-editorial text-2xl sm:text-3xl font-bold">
              Laravel Blade Architecture & Templates
            </h1>
            <p className="text-xs sm:text-sm text-teal-100 max-w-2xl leading-relaxed">
              Below are the exact, production-ready Laravel Blade templates, components, and controllers built to match the Premier Specialist Clinic design specifications.
            </p>
          </div>

          <button
            type="button"
            onClick={onBackToPreview}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-white text-[#103d52] hover:bg-teal-50 font-semibold text-xs shadow-sm transition-all self-start md:self-auto"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Live Website</span>
          </button>
        </div>
      </div>

      {/* Main Explorer Two-Column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Blade Files Sidebar (Col 1-4) */}
        <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider text-slate-700">
              <Folder className="w-4 h-4 text-[#247871]" />
              <span>Project Structure</span>
            </div>
            <span className="text-[10px] font-semibold text-slate-400 bg-slate-100 px-2 py-0.5 rounded">
              {LARAVEL_BLADE_FILES.length} Files
            </span>
          </div>

          <div className="space-y-1.5">
            {LARAVEL_BLADE_FILES.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  type="button"
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left p-3 rounded-xl transition-all flex items-start gap-3 text-xs ${
                    isSelected
                      ? 'bg-[#103d52] text-white shadow-sm'
                      : 'hover:bg-slate-50 text-slate-700 border border-transparent'
                  }`}
                >
                  <FileCode className={`w-4 h-4 flex-shrink-0 mt-0.5 ${isSelected ? 'text-teal-200' : 'text-[#247871]'}`} />
                  <div className="overflow-hidden">
                    <p className="font-semibold truncate">{file.name}</p>
                    <p className={`text-[10px] truncate ${isSelected ? 'text-teal-100' : 'text-slate-400'}`}>
                      {file.path}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Quick Setup Instructions Box */}
          <div className="mt-6 pt-4 border-t border-slate-100 space-y-2.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-[#103d52]">
              <Terminal className="w-3.5 h-3.5 text-[#247871]" />
              <span>Laravel CLI Commands</span>
            </div>
            <div className="bg-slate-900 text-slate-200 font-mono text-[11px] p-3 rounded-lg space-y-1 overflow-x-auto">
              <p><span className="text-emerald-400">composer</span> create-project laravel/laravel clinic</p>
              <p><span className="text-emerald-400">npm</span> install -D tailwindcss @tailwindcss/vite</p>
              <p><span className="text-emerald-400">php</span> artisan serve</p>
            </div>
          </div>
        </div>

        {/* Right: Code Viewer (Col 5-12) */}
        <div className="lg:col-span-8 bg-slate-900 text-slate-100 rounded-2xl border border-slate-800 shadow-xl overflow-hidden flex flex-col">
          
          {/* File Header Bar */}
          <div className="bg-slate-950/80 px-6 py-4 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs text-teal-400 font-semibold">{selectedFile.path}</span>
                <span className="bg-slate-800 text-slate-300 text-[10px] px-2 py-0.5 rounded font-mono uppercase">
                  {selectedFile.type}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 max-w-lg">
                {selectedFile.description}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleCopy}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors border border-slate-700"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied!' : 'Copy Code'}</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadAll}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-800/60 hover:bg-teal-700/60 text-xs font-semibold text-teal-200 transition-colors border border-teal-700/50"
                title="Download this template"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Save</span>
              </button>
            </div>
          </div>

          {/* Code Text Area */}
          <div className="p-6 overflow-x-auto flex-grow max-h-[640px] font-mono text-xs leading-relaxed text-slate-200 scrollbar-thin">
            <pre><code>{selectedFile.code}</code></pre>
          </div>

          {/* Code Footer */}
          <div className="bg-slate-950/90 px-6 py-2.5 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Encoding: UTF-8 &bull; Engine: Blade</span>
            <span className="text-teal-400">All Tailwind utility classes validated</span>
          </div>

        </div>

      </div>

    </div>
  );
};
