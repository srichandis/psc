import React from 'react';
import { X, Calendar, CheckCircle2, Phone, Stethoscope, ArrowRight } from 'lucide-react';
import { Specialist } from '../types';
import { CLINIC_INFO } from '../data/clinicData';

interface DoctorProfileModalProps {
  specialist: Specialist | null;
  onClose: () => void;
  onBookWithDoctor: (specialistId: string) => void;
}

export const DoctorProfileModal: React.FC<DoctorProfileModalProps> = ({
  specialist,
  onClose,
  onBookWithDoctor,
}) => {
  if (!specialist) return null;

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6"
      role="dialog"
      aria-modal="true"
    >
      <div className="relative bg-white rounded-2xl shadow-2xl border border-slate-100 max-w-2xl w-full overflow-hidden animate-scaleIn">
        
        {/* Header with Doctor Headshot */}
        <div className="bg-[#103d52] p-6 sm:p-8 text-white relative">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-1 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5">
            <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl overflow-hidden border-2 border-white/40 shadow-md flex-shrink-0">
              <img
                src={specialist.image}
                alt={specialist.name}
                className="w-full h-full object-cover object-center"
              />
            </div>

            <div className="text-center sm:text-left space-y-1">
              <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-teal-800/80 text-teal-100 border border-teal-700/50">
                {specialist.specialty}
              </span>
              <h3 className="font-editorial text-2xl sm:text-3xl font-bold">
                {specialist.name}
              </h3>
              <p className="text-xs text-teal-200 font-medium">
                {specialist.qualifications}
              </p>
              <p className="text-xs sm:text-sm text-white/90 font-semibold pt-0.5">
                {specialist.role}
              </p>
            </div>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 space-y-6 text-slate-700 text-xs sm:text-sm">
          {/* Biography */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Professional Biography
            </h4>
            <p className="text-slate-600 leading-relaxed">
              {specialist.bio}
            </p>
          </div>

          {/* Clinical Interests */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Areas of Clinical Focus
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {specialist.specialInterests.map((interest) => (
                <div key={interest} className="flex items-start gap-2 text-xs text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-[#247871] flex-shrink-0 mt-0.5" />
                  <span>{interest}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Consultation Days */}
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-200/80 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#103d52]/10 text-[#103d52] flex items-center justify-center">
                <Calendar className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-800">Consulting Schedule</p>
                <p className="text-[11px] text-slate-500">{specialist.consultingDays} at Coomera Clinic</p>
              </div>
            </div>

            <span className="text-[11px] font-bold text-[#247871] bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
              Accepting New Patients
            </span>
          </div>

          {/* Action Footer */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-slate-100">
            <a
              href={`tel:${CLINIC_INFO.phoneClean}`}
              className="inline-flex items-center gap-2 text-xs font-semibold text-[#103d52] hover:text-[#247871]"
            >
              <Phone className="w-4 h-4 text-[#247871]" />
              <span>Call Reception {CLINIC_INFO.phone}</span>
            </a>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="w-1/2 sm:w-auto px-4 py-2.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onBookWithDoctor(specialist.id);
                }}
                className="w-1/2 sm:w-auto inline-flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-lg bg-[#103d52] hover:bg-[#0c2b3a] text-white text-xs font-semibold shadow-sm transition-all"
              >
                <span>Book Appointment</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
