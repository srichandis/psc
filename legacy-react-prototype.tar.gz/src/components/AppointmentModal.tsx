import React, { useState } from 'react';
import { X, CheckCircle, AlertCircle, Calendar, Clock, User, Phone, Mail, FileCheck } from 'lucide-react';
import { SPECIALISTS, CLINIC_INFO } from '../data/clinicData';
import { AppointmentFormState } from '../types';

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedSpecialistId?: string;
}

export const AppointmentModal: React.FC<AppointmentModalProps> = ({
  isOpen,
  onClose,
  preselectedSpecialistId,
}) => {
  const [formData, setFormData] = useState<AppointmentFormState>({
    fullName: '',
    phone: '',
    email: '',
    specialistId: preselectedSpecialistId || '',
    specialty: 'Neurology',
    hasReferral: 'yes',
    preferredDate: '',
    preferredTime: 'Morning (9:00am - 12:00pm)',
    notes: '',
  });

  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const handleReset = () => {
    setSubmitted(false);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6"
      role="dialog"
      aria-modal="true"
      id="appointment-booking-modal"
    >
      <div className="relative bg-white rounded-2xl shadow-2xl border border-slate-100 max-w-lg w-full overflow-hidden animate-scaleIn">
        
        {/* Header */}
        <div className="bg-[#103d52] px-6 py-5 text-white flex items-center justify-between">
          <div>
            <h3 className="font-editorial text-2xl font-bold">Request an Appointment</h3>
            <p className="text-xs text-teal-100 mt-0.5">
              Premier Specialist Clinic &bull; Coomera Medical Hub
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6">
          {!submitted ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Important Referral Advisory Banner */}
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 flex items-start gap-2.5 text-xs text-amber-900">
                <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                <p>
                  <strong>Medicare Note:</strong> A valid GP or specialist referral is required to receive Medicare rebates for specialist consultations.
                </p>
              </div>

              {/* Patient Name */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Patient Full Name <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. John Smith"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className="w-full pl-9 pr-3.5 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#103d52] focus:border-transparent"
                  />
                </div>
              </div>

              {/* Phone & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Contact Phone <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="tel"
                      required
                      placeholder="e.g. 0412 345 678"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full pl-9 pr-3.5 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#103d52] focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="email"
                      placeholder="john@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full pl-9 pr-3.5 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#103d52] focus:border-transparent"
                    />
                  </div>
                </div>
              </div>

              {/* Specialist / Specialty Selection */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Requested Specialist or Discipline
                </label>
                <select
                  value={formData.specialistId}
                  onChange={(e) => setFormData({ ...formData, specialistId: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#103d52] focus:border-transparent bg-white"
                >
                  <option value="">Any Available Specialist in Specialty</option>
                  {SPECIALISTS.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} — {s.role}
                    </option>
                  ))}
                </select>
              </div>

              {/* Referral Status */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Do you currently hold a GP referral?
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { val: 'yes', label: 'Yes, I have it' },
                    { val: 'pending', label: 'Getting one' },
                    { val: 'no', label: 'Need guidance' },
                  ].map((item) => (
                    <button
                      key={item.val}
                      type="button"
                      onClick={() => setFormData({ ...formData, hasReferral: item.val as any })}
                      className={`py-2 px-2 text-center rounded-lg border text-xs font-medium transition-all ${
                        formData.hasReferral === item.val
                          ? 'border-[#103d52] bg-[#103d52]/5 text-[#103d52] font-semibold'
                          : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Preferred Time */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Preferred Date
                  </label>
                  <div className="relative">
                    <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="date"
                      value={formData.preferredDate}
                      onChange={(e) => setFormData({ ...formData, preferredDate: e.target.value })}
                      className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#103d52] focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Preferred Time Window
                  </label>
                  <div className="relative">
                    <Clock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <select
                      value={formData.preferredTime}
                      onChange={(e) => setFormData({ ...formData, preferredTime: e.target.value })}
                      className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#103d52] focus:border-transparent bg-white"
                    >
                      <option>Morning (8:30am - 12:00pm)</option>
                      <option>Afternoon (1:00pm - 5:00pm)</option>
                      <option>Next available</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Referral Details / Clinical Notes (Optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="Referring doctor, relevant health symptoms, or scheduling preferences..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#103d52] focus:border-transparent"
                />
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="px-5 py-2.5 text-xs font-semibold text-white bg-[#103d52] hover:bg-[#0c2b3a] rounded-lg shadow-sm active:scale-95 transition-all"
                >
                  Submit Appointment Request
                </button>
              </div>
            </form>
          ) : (
            <div className="py-6 text-center space-y-4">
              <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto ring-4 ring-emerald-50">
                <CheckCircle className="w-8 h-8 text-[#247871]" />
              </div>

              <div className="space-y-1">
                <h4 className="font-editorial text-2xl font-bold text-[#103d52]">
                  Appointment Request Received
                </h4>
                <p className="text-xs text-slate-600 max-w-sm mx-auto">
                  Thank you, <strong>{formData.fullName}</strong>. Our reception team will review your referral information and call you at{' '}
                  <span className="font-semibold text-slate-800">{formData.phone}</span> to confirm your booking time.
                </p>
              </div>

              <div className="bg-slate-50 rounded-xl p-4 text-left text-xs space-y-1.5 border border-slate-200/80">
                <div className="flex justify-between">
                  <span className="text-slate-500">Clinic:</span>
                  <span className="font-semibold text-slate-800">{CLINIC_INFO.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Location:</span>
                  <span className="font-semibold text-slate-800">{CLINIC_INFO.address}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Direct Contact:</span>
                  <span className="font-semibold text-slate-800">{CLINIC_INFO.phone}</span>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleReset}
                  className="px-6 py-2.5 bg-[#103d52] text-white rounded-lg text-xs font-semibold hover:bg-[#0c2b3a] shadow-sm transition-all"
                >
                  Return to Clinic Home
                </button>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
