import React, { useState } from 'react';
import { ArrowRight, Filter } from 'lucide-react';
import { SPECIALISTS } from '../data/clinicData';
import { Specialist } from '../types';

interface SpecialistsSectionProps {
  onSelectSpecialist: (specialist: Specialist) => void;
}

export const SpecialistsSection: React.FC<SpecialistsSectionProps> = ({ onSelectSpecialist }) => {
  const [selectedFilter, setSelectedFilter] = useState<string>('All');

  const filters = ['All', 'Neurology', 'Psychiatry', 'Endocrinology', 'Nephrology', 'Psychology'];

  const filteredSpecialists = selectedFilter === 'All'
    ? SPECIALISTS
    : SPECIALISTS.filter(s => s.specialty === selectedFilter);

  return (
    <section id="specialists" className="scroll-mt-24 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 sm:mb-10 gap-4">
          <div className="space-y-2 max-w-2xl">
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#247871] block">
              OUR SPECIALISTS
            </span>
            <h2 className="font-editorial text-3xl sm:text-4xl font-bold text-[#103d52]">
              Meet Our Specialists
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed pt-1">
              Our multidisciplinary team provides specialist assessment and care across a range of neurological, psychological, psychiatric, endocrine and kidney conditions.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <a
              href="#specialists"
              onClick={(e) => {
                e.preventDefault();
                setSelectedFilter('All');
              }}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-[#103d52] hover:text-[#247871] transition-colors whitespace-nowrap group"
              id="view-all-specialists-link"
            >
              <span>View All Specialists</span>
              <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
            </a>
          </div>
        </div>

        {/* Specialty Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-4 scrollbar-none">
          <div className="flex items-center gap-1.5 text-xs text-slate-400 mr-2 font-medium">
            <Filter className="w-3.5 h-3.5" />
            <span>Filter:</span>
          </div>
          {filters.map((filter) => (
            <button
              key={filter}
              type="button"
              onClick={() => setSelectedFilter(filter)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                selectedFilter === filter
                  ? 'bg-[#103d52] text-white shadow-sm'
                  : 'bg-white text-slate-600 border border-slate-200 hover:border-slate-300 hover:bg-slate-50'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        {/* 6 Specialist Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-5 sm:gap-6">
          {filteredSpecialists.map((specialist) => (
            <div
              key={specialist.id}
              className="bg-white rounded-xl border border-slate-200/90 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 flex flex-col overflow-hidden group cursor-pointer"
              onClick={() => onSelectSpecialist(specialist)}
              id={`specialist-card-${specialist.id}`}
            >
              {/* Headshot Image */}
              <div className="aspect-[4/3] w-full overflow-hidden bg-slate-100 relative">
                <img
                  src={specialist.image}
                  alt={specialist.name}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/25 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>

              {/* Specialist Info */}
              <div className="p-4 sm:p-5 flex flex-col flex-grow justify-between">
                <div className="space-y-1.5">
                  <h3 className="font-editorial text-lg sm:text-xl font-bold text-[#103d52] leading-snug group-hover:text-[#247871] transition-colors">
                    {{ ...specialist }.name}
                  </h3>
                  <p className="text-[11px] font-medium text-slate-500 tracking-tight leading-normal min-h-[32px]">
                    {specialist.qualifications}
                  </p>
                  <p className="text-xs font-semibold text-[#247871] pt-1 leading-snug">
                    {specialist.role}
                  </p>
                </div>

                <div className="pt-4 mt-auto border-t border-slate-100">
                  <button
                    type="button"
                    className="inline-flex items-center gap-1 text-xs font-bold text-[#103d52] group-hover:text-[#247871] transition-colors"
                  >
                    <span>View Profile</span>
                    <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
