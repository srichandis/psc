export interface Specialist {
  id: string;
  name: string;
  qualifications: string;
  role: string;
  specialty: 'Neurology' | 'Psychiatry' | 'Endocrinology' | 'Nephrology' | 'Psychology';
  image: string;
  bio: string;
  consultingDays: string;
  specialInterests: string[];
}

export interface Specialty {
  id: string;
  name: string;
  shortDesc: string;
  fullDesc: string;
  iconName: 'Brain' | 'HeadProfile' | 'PsychiatryCare' | 'Butterfly' | 'Kidneys';
  conditions: string[];
  diagnosticServices: string[];
}

export interface ProcessStep {
  number: string;
  title: string;
  description: string;
  icon: 'file' | 'phone' | 'calendar' | 'users';
}

export interface AppointmentFormState {
  fullName: string;
  phone: string;
  email: string;
  specialistId: string;
  specialty: string;
  hasReferral: 'yes' | 'pending' | 'no';
  preferredDate: string;
  preferredTime: string;
  notes: string;
}

export interface BladeFileTemplate {
  path: string;
  name: string;
  type: 'layout' | 'component' | 'view' | 'controller' | 'route' | 'config';
  description: string;
  code: string;
}
