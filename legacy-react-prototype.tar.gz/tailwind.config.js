/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./resources/**/*.blade.php",
    "./resources/**/*.js",
    "./resources/**/*.vue",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          teal: '#103d52',
          dark: '#0c2b3a',
          hover: '#164e68',
          accent: '#237871',
          sage: '#388e85',
          light: '#f4f8fa',
        }
      },
      fontFamily: {
        serif: ['Newsreader', 'Georgia', 'serif'],
        sans: ['Plus Jakarta Sans', 'system-ui', 'sans-serif'],
        script: ['Caveat', 'cursive'],
      }
    },
  },
  plugins: [],
}
